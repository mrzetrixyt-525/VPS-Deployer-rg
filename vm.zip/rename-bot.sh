#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

# Change the RGNODES display label in .env and restart the managed service if installed.
# This does not change the Discord account username or the host/guest hostname.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
APP_DIR="${RGNODES_APP_DIR:-$SCRIPT_DIR}"
ENV_FILE="$APP_DIR/.env"
SERVICE_NAME="${RGNODES_SERVICE_NAME:-bot.service}"

if [[ "$EUID" -ne 0 ]]; then
  printf '[RGNODES] Run as root: sudo bash rename-bot.sh "New Display Name"\n' >&2
  exit 1
fi
if [[ "$#" -ne 1 ]]; then
  printf 'Usage: sudo bash rename-bot.sh "RGNODES™ New Name"\n' >&2
  exit 2
fi
[[ -f "$ENV_FILE" && ! -L "$ENV_FILE" ]] || { printf '[RGNODES] Safe .env file not found: %s\n' "$ENV_FILE" >&2; exit 1; }
NAME="$1"
python3 - "$ENV_FILE" "$NAME" <<'PYVALID'
import sys
name=sys.argv[2]
blocked=set('=#$\\\"\'`')
if not 2 <= len(name) <= 32 or any(ord(c)<32 or ord(c)==127 for c in name) or any(c in blocked for c in name):
    raise SystemExit('[RGNODES] Display name must be 2-32 printable characters; avoid = # $ backslash quotes and backticks.')
PYVALID
chmod 600 "$ENV_FILE"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="$ENV_FILE.backup.$STAMP"
cp -p -- "$ENV_FILE" "$BACKUP"
chmod 600 "$BACKUP"
python3 - "$ENV_FILE" "$NAME" <<'PYWRITE'
import os,sys,tempfile
from pathlib import Path
path=Path(sys.argv[1]); name=sys.argv[2]
lines=path.read_text(encoding='utf-8', errors='replace').splitlines()
out=[]; found=False
for line in lines:
    stripped=line.strip()
    if stripped and not stripped.startswith('#') and '=' in stripped and stripped.split('=',1)[0].strip()=='BOT_NAME':
        if not found:
            out.append('BOT_NAME='+name); found=True
    else:
        out.append(line)
if not found: out.append('BOT_NAME='+name)
fd,tmp=tempfile.mkstemp(prefix='.env-rename-',dir=str(path.parent))
try:
    with os.fdopen(fd,'w',encoding='utf-8') as f:
        f.write('\n'.join(out)+'\n'); f.flush(); os.fsync(f.fileno())
    os.chmod(tmp,0o600); os.replace(tmp,path)
finally:
    try: os.unlink(tmp)
    except FileNotFoundError: pass
PYWRITE
if command -v systemctl >/dev/null 2>&1 && systemctl cat "$SERVICE_NAME" >/dev/null 2>&1; then
  if systemctl restart "$SERVICE_NAME"; then
    printf '[RGNODES] Display name changed to: %s\n[RGNODES] Service restarted: %s\n[RGNODES] Backup: %s\n' "$NAME" "$SERVICE_NAME" "$BACKUP"
  else
    cp -p -- "$BACKUP" "$ENV_FILE"; chmod 600 "$ENV_FILE"
    systemctl restart "$SERVICE_NAME" >/dev/null 2>&1 || true
    printf '[RGNODES] Restart failed; previous .env was restored. Check: journalctl -u %s -n 100 --no-pager\n' "$SERVICE_NAME" >&2
    exit 1
  fi
else
  printf '[RGNODES] Display name saved: %s\n[RGNODES] No systemd unit named %s was found; restart your bot process manually.\n[RGNODES] Backup: %s\n' "$NAME" "$SERVICE_NAME" "$BACKUP"
fi
