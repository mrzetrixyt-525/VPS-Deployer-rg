#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
umask 077

if [[ "${1:-}" == '-h' || "${1:-}" == '--help' ]]; then
  printf 'Usage: sudo bash node.sh [--api-key KEY] [--prompt-api-key] [--port 18443] [--host 127.0.0.1]\n'
  exit 0
fi

# RGNODES™ compact remote-node installer. The node agent and KVM controller are
# embedded and SHA-256 verified; no sidecar source files are needed in the bundle.
NODE_AGENT_ZLIB_B64='eNrVG+1y28bxP5/iwkwLICFBkKZoRQndUWwlVu1YbMR4ktFoEBA4iohAALkDZKka/euT9NH6JN29D+BAgpScejqtMjVxX7t7e/t9188/G5ScDRZxOqDpDcnvilWWPut0u90fv3939urk/F//+CdhdJ0VlKRZRElwRdOCLDNGgrJYwXccBgWNyJv3P5D3s3MSZmnBsiShjGQ5ZUERZyl3O53zIkriRT9Lkzvyej6fkePZKUxe5zBjkVDyIS5WZJEVbn531CHk+5M5IYMgjwd5nF41Oq5o4a8yXvi8CAq+NRSEIeXcj9NlBmOzs/O5HKO3NCxhF389P3t3RO67gHsdpFH3qCs4kGRhkAw4MuIm52GRKOKIhWhKTt7/YHUfOp3jetewsyPycx820n9D7wiwBAczFv9djX1LAwZ8cF23M19p1qX0Bvri9Ca7ppwEhK9okgiG4qaIIou75LQguJe84ERwDfAid5fxVclo1OvEaUGvWFzc9dcBu1ZHoGiXmw2QsQCMxACDAx+h+avc1q8kYFflGghy8bA7S5atie8vywKA+z6J13nGgIA0zQp5hp2O7mNXecA41e3VOgj1d5wHUcSA/7rjN56l+jurelcBX4E06CZflUWc1K2E3laNLLymRdUqFznLQgN+Ea+pJH5VFLnLKRPclYPfBpyirP1Ify8pL14DK0Aue2S+YjSIgB84eC6WSBjAGKRLr59Bs9PpnPw8O3k5P3nlg3y/nL/1z18fjw4mZEqsw2h0cBDQKBw/e+4dHj4/9CYRpc+98eEiWISj8fhw6Y2HIaUHXjScHCy/opPRgo5GkwNvDN+RBdAjuiRIjh/mpe2g7BOCfTwNct3GP6EgoFKpbQ2QCQOUS6tHLAb/0DTMcENTqyyW/UPLIQEny3ox/qGIJXFKQfY2h/AvXopRF8CygiM22wKSiOVsz8W/myDhwIMLEEP71hHQbxG0BJIncWE7F8Ojy8vW1TGcBKxGIBfPLsmXxBaf40tBB2wSmw55QcaEJpwSz2kFwyjIawpysZYLegJwZ2PY6xFP9AV+AeKc9OBDESC5LAZRlFyeUJrbnjs8kJ0LvWLRtgKHoEtNIn2NoGNsUS3sK5wdgy6WlWlkr4NbQAg0ruPUHnri09YAcYlDviCinwwkSgf2OXSQU3LaC+IpLrmeKVEsWGsJ0qQGN0GcCLswVTwp2N0eIVvTNVrSTyhnOYoXYDflpFUYgQgxF6RgSkbCjon2hXdJpqB8P9D1HHd1ZLULqN4yCqhcOLyUrByNtxbQ5IkojzUDd6E1ObwTNb1Fw07Ozk8Yy9jRpsDed0tOwTWh5HbFPtQ3eNQQbDa2XO9BLMOZgEpIUY9UgqipkLxV62CelDlbrFLipMVrQ6oqiWojDH8M2pSSGPSprwclj7XDrmxczK9RnYTtd7HllxxcJEieJYkuc1RJFFS3RVSr0WWSBYWNtloLrRyyHFdoQUFvQcQqk+RdOuYRnIgfdNedWkI5l5sO1sixSpUanKimd8FKwoZrG96rh2AZDgXri4o1l81hf3FXUO4rtoqZ4rt9mua3mCcb5kRA74dwwHgAGXerpu1gdOIZM5HfMOm+IcL6cHHQFSfcHNbYxbg88uaEJaNUj+P3xnAtHUoKK0QgijXQLXk0hrRQ1pAfjF3Jg0fxFB/GCMpfGogxGVK4ECvqTn1kWlghXPSv6Z2PMYHPZPBgr2T0cLQjqnBI/wXhhdJlXuYgbkIx1Tp3BfJBGUe8tlVFjWhYlbjDRiHYqpbW8oiB9i5AjYjTAKYA4lI3yT5QhhpgePaFDE03nbtBNy69eH50CctYnDeFX0+rxiTfVOzqY9BnQ5h40xNONSuL6TNPOyJTh1Fb0QZUYZ3LytRuUCTANGkswANNjTWvTt6/++nt261ZiNeYNjudnWzNoYztn4PWYzpn5YYs632p3+ZguKLh9fQ7CEiMVc6mkUecrvwGp0p7skPSXTeAQNNcfRcn9F1WfIf60+47hqPnKAbwP3UcQqqWuMAyIRm7nstNnNzmMTMFr4I43oCIu44ILNEBbMz9qyRbBIlfppAagbpAOAY8IxBac5DMtsOPc/SQOmFw49xXnzZIlVzvaAHbYp4d566CjZ5Zf4pkJ3crcojev+xcl0khyNvy3M15QAVmBdFGd5nynIbxEiT/EQBJluWLILze7I7Ta19kmg0f9B732n6aQogUk/2ClRxybV8meT5mKzYLPogPxWFM3CnPkhtM/AA+qGkYF5A9BgmagWhHgsjobzQsyAdIJ7FvAD5D4iJLEDjuYoooJLvKP+HsMmGDaHpjW6pYoDOk2fH8NcpLe2ZtOQ2boimbkvsa/IM2iXp/kotpNRv8GfbMGjxAHgcL2D4k+mbuxIIY3EbNZshs6jKFgB5zAU5AT2LcuTKkDZENgVdxFBQYdmxgZpLrKLtxKC2G0xLqYbwMPY+Qpnm8fVhA5zrmmMtD7C1yVoBmuo+KROQFHp70/TgE5yWLI3Y1qYedP/tnb5xPQJHGUw+28XCNVaSpQSdGhcI7+ThkRGF3ENhFjakixhKRkJEz8KyEsALmqRVuRNGe2ipFgaQFd8GnFqN5EoSaqE97LqGolJAFZj1oJIQAbR2Q2PufiZd5o9EfRrUGxSQK2RUEUvngQ8aSqFLeOpxQZRaXr4LRwcRW/HEggriN4isMahzy2ZS01zf20Qd7hGAsUTUnQ5eqmpT0gWQJWQiNvgb7opZAnlKEKxQWRhMKkVQz+IEZtqhmISh9sphQ1p22BTgHfzv54acB7O0mxsJSmohASsUgoJA2NmGMryznqaJtbkNaA6y4YaiTMVXhFGiJtmKNiAhcViWnOh5alHFSWWsMZGzlQGtjPcNKmqzv/fqNYX36ctULXYX8JoOEWh3gi1+/blQRdRGxstKKmTEXTE9DqvH2kM7KHqhObYyxGzNgTSN5AZ7f87z97JMBATCMrvNCFEGLLCNJhgaqowM4kecl9FYlYRpDx0j1cZqQxmcIA1uQM2Pbkhyw9pEh+BfkEM/c1CqjOKcLqgCTqoJqZdyNI5+2u1dBiE4Za5MkukfN2FhxXU9S3NRKh9z0HucmUqwh7GGqkrqLegO9ilE9DeBSiSGkTyEwhvl5uYBwwKdplGegqVUqrvrj/Gbc7tZnP3379vSlfzp7P5Y5RmPj9fLJY8snLcuBbyYBVcS0FVIas3pkbKh1k37L2gY7eRLYSY9MWsFOGmDFKdcojRMNe0QE7z56LTMZurDiHLfeF/wDo11Q/ABG4c/QFf9Zl43cjYUY2XrNBE1XzwBCa/EM1lmchRZaSjF3u0hlBjGyOCX+deM0ore2WO2QL8lwu3Db8OMbWLf5agQZ4x015O3DqxZtV+h21mua/FG1m33ntLUP4adLlqCzVPm+vgNQWX4Ph7Ew2mmWn38HmtUU28IrCH40wOumMeQz8fLOzdgVnLBK2af31k+QWPSP8SLIOiJaQfp4s9YX10ODoetZD80zFUVZhd4GlHVWPXIPRAUWgs98/0HjDBE+2ZOxU0VIAQ/jGCUwvkozRjcU8z853cdOdf9pilNsP8bJR6mbsDd9Ub7G5BJ/+Sr7IH5D4KdQQrGxpyjfUhjia5qidhka2HqZYg0snbOINe3yigY8Tku69/DEeoUMwPaGWMX8dNo5eZJ2TvZqp/5bgIxd/0HdbfBi38H/F/R38j+rv8PR4adW4MleBZ78UQU2a12m6zZAQ4QSJjCXvCqD5LwIwuv6StZuuaZVhKpCkb8M1jFEflNd0z3+zj99dzKfdOpbVLHMX4BzszlNls4eKcJxV0HitMCvLC9s1XM6m/14Nj8TUUyPVJ3vJ/77ydm7t7/0zDvKXfc7Dd6ogquszRp0NtMHOWJjrRpYByKttoAm5kj4eRzasy11BG0cNqH2iK5kf9wuFPiWw9oFXp+56rB3FNRVJV0ypqr11Ur3DjTguNK5+siT7Mpfg3TgXRIeaY8s10DFFxCzc+P4PyfHN1kc4fQrzEdDyAHxYUeQ8AHQwe4wV4IB7hrlarzQW3Yv7oWoaCmU82zn4ZLcAyryJ0wP+EMXECclX6lakCGS2k1J6uT7kipqN0gEhQtgxzjXjcp1znU2gRexHB9qCP2XlWbHFZezVd3DKJAIuUasaEWylGOVCnG2TZGmzrZegjEGdvTnd9JLBljxl49eBkjQ15DhY+5aTHej24T1lqZXxcoSWaiNyRFu0HH2Lg3CFe2/lGkO0pFmfV4IU9dcVS9q1IZw6AOWwVwsj1CJsT6LQF2f0C3rQG9lFQeNi6QK5dBVV0MoPgVw5ohIw3sRFAXrA8Q4pdFlp+06pe1OSeDcLPkusiyxNXpHJC74xMYV6R2cuSrdaNi9ilRjX1Hmf38y39yTqHSq/eC3Din+YuFNG8QULpPuo7qCNe+lhMjX/HLajGcl2mNv2CP3XVF66x6RbpnWS7sb/lHu28QnCQVdr16AWXuxjTwPsUmpRnTZNWhfF88sDvHOr8uu0Edzw1PjhEduBT+SzubDtCdQbF6Kfzwq46HbBi7pZpXr3pP9P87SrbDAMjw5REAC075JEzlp0jJJ89nadyVb3fI+nT9gBRKwMh8tMPtRbMn3uCHfoCG+uGNDMKYa4gPE/289/EwLnXpBaT2CcA9jWrDtjlsS4S3UKxqBpXHzveVULM9ytuJeBeQbyOVURQ6bWNk8VO9xtkPftnr3TZDEskSMz2gkGKuJbZFFd/pUmXA5Il6Xc52N4EkXEoVvx29u4/qNu4uN/ehq61Q4UH3dIbihhmR5bWcWYFR9n7Jto7qLHgsvh602Du8pGT8OfKOyad774+u5nSX0JkMff0jQ/pjg6Q8Knvqo4KkPC/Y8LjAfGHzleduDrQ8Mmo8Mnm7Su/UbBHy3tfEqYXu6ZIKeKlsXfVHc9o4u2xcAN4wF0Nq14GEr+3jCO4VWM3TYMENbLxe625jsWjx7UjHxrfgroZGi19m6JWzF7JmYUVNhibONrkqdnwL1YCdUmSuugzityvkYlzN5SyG+3WP11lvcNjEbAqEQ7APinlrGO/+tF/3yvguf9ddv/y3HQII5kK9fkttWv4/+G4wQkBSUSTFtuQw4/v7k3dx/DW5RlL5Hz10P/htqW7cDLuaQMB9j7in4gxoDOoedWGZnP0osh+PxM8vZj0JF6Pupx3/949mp/+bkF2Vs9S0Xl/V0BC1+EDhv3g1hT5VCqAsis88h3xDTI0mreX7HC7o+ucUQ4RiPHqwlqegl9mj8pUjGAkgCGHdMc+02r1ftIXpCgVEUx6AxOTh4duDsQznDmeLSeUHJsC8WIFwjPa8MtSpWCAwy+a+QOcZ8NwroOkv9QhQNkHFoBM0JenPTJs8eT7tUjm6KtfH/WxGXq6l4q5CS+4rMh6P7is4Hq5m3b8UmikLxA6ENw5tYO8+SxMfbbwaRwtRzDxqPDN7Qu0UWsOgUJ7AyL1oem8IegiTZgYf5YZJB3o7qDmfp+xgj+74IeH0fld/3VVwmLUHn3xkAbc8='
NODE_AGENT_SHA256='1b8e666bf46e8d8732dacde6a38d3b23a8f8caf7ac6dcfb04ca3a977a8578020'
VPSCTL_ZLIB_B64='eNrdfdt220iS4Lu+AqXqXhA2eJEsu6spwTMqW3Zpy7I1slzds7KGBZGgiBYJwACoy7B5zjzsH+x+wX7afMnGJTORiQtJuVx9dtZ1ygaBzMhbZGREZFy+/647z9LuVRh1g+jWSh7ySRw929re3j57+/7D66OP//k//4/1y+lHaxhHeRpPp0Fq/ed//G/r519Ouv9ydPKpOw2vbsM0t+Jo+tDZ2jqfBNbrMBvG6ci6inNr6E+nmZXD21+H8Szx81+tMMqDdOwPAyuLrTDPrJmfz9MAWpjN/GhkZXP+OvQjKw1mfhhtZbl/NQ2su0kIfyMwf5jP/Sl1LJ1HeTgLrDCzfCgPb6FvFvYJS8z84SSMgo6FHdPGENwncRZk1G0CEydB6udhHGUdHP3WOI1n1mAwnmPfBgMrnCUxDNOPojjnclvyVXqd+GkWuNaVnwUv9lxr4mcTmBfXChN/NEqDLHOtv2Vx5FoxPKVQMguGaZDDDygY3OM/8zycwr/x8CbI4d/5VZLGQ6qZPcBfeTBLxjB6eILBcu9gNrEZ2bVT+Mkf5ukU3nfS4Ms8yHL5/Yx/uvgZRhtxWZyT4D7X4Ig3sBb+dZBu5elDf8uCP+LzeBjl063gfhgkuXVM747SNE65EH21POt9HAVbW2cfPpzDD+xZK84610EOSNayBWoNYN4HWMR2Lbt766eITN30OopHQda+TTLbcbbefXj18+DN8bsjgEPgupbdKRayM4UZs7eOTw7fHg1eH5+51uvjjz/z08ejo9fy6dXZ0Tk/nxydH+ITwLsQAO+tcZzC32FktexwBsPObNcehdkN/psFwYj/pTWDp1mQ+7ZzufX+6PwvH85+Bkg1gwMsHIgCOD45rGR+NQ2HttPJ8jRMWo4FLZc/SsCDE4BkQteg0lcEPQrTYJgXIGFO7oK05Wz9eHb8+m0JwOmnH98dvxrwp8H7wxMCUVTeOj08O3p/Pjh+U1tPfn1/fnT25vBVufLZ0eG7gSh6dvQvn47Pjl6XpkcrcXz6y54qBvOap/OgOgxcloW9I7+79gMtTxzZyy3Zqw8f3tV2l1rAr4NXx6/PyiPlMm8Pz4/+cvivzfVFgfrar99/REy6V+upUKkBGlSA3u906D/3hw79h3CTaZi34BMMeGwpeIBlb84H54c/vjuqxzP1WcOyAW2eOhSjL1uH78+PByfH74/fvzWBah8GR+8R6tety9YoGFsDADkAat+K/BkQLnjlz6e5w4QCyQqQQqCuEZ4ILQCukQizhmraoaqC9rTOH5KASI9r/eJP5/zsGFAlBK1D42nsN3eJHvDPLUL0uPAj+kaEcsy1re888QALwA9IYRimHUZj23HFjzb9wr77YRZow2nZURy1x2EU5rAEqgkxRAK6fk5c68MtHLmwbqUp4taLSTo5/Ovg7PAEcGLm37d2XGsWRq3dXbdYShuLEN0+PBm8/dF2d3cdGDq+fXX6yay406urCMVsd6dHtY7fD5Bci2rPjeLwDYsTOceGsAq1o9WQAGR7tQ1qEKhVwO7zYyBClYGK0eswZFl9xD/oQCqDFjPRBIRGv6tDaByOHGsTKDWu3ecI76cPH8+pj2dHH4/OfjmCTwJsryNnVmBbTVHqFMMguBUgu51eDZBSWbFK9AlGKr/IfugjKZeBqrLmL/j6wy9HZ68+nJwcY0/Pjz+osfzpuUDL2g7V1gXYnecSTV8fnb778K80/I8/wWmmACO6IuBe588lyHXVbLfX+aHn6KPVip2+OpdI3esIuH9+Xtvjak1AMSgqN4harDdnR0f4WZSU8CV4bsjo9oraMCU/cBvMOn06e4fn2GLLsudXwFHP+7sAb8/u25M8T7J+tzucxvNRm7mjDpcBPmzWTYNpAHxv1s2CFKhMdxwDzy/fdrlgm4C1uUSbIIWz67Y/G73Y68CT7Wrt7n5du3/zZ7OHSru7m7e793XtRjGIJpV299a3OwquQj/q7+yUG+3wl06cXne5fX7fvZqDMBU8BN2pnwMn3+Vy7Z2d9nUQBWk45D5zM1+G8d2u0dDu5g3F8c1dnM7KDe1u1tCzjRuCo/M+rIzn2apmlluH744PPx599BZy6QjloE0Dc135kxBD+7prfKXl077u8VfuZZ971KU1Ktar8nlX+7xb/fxM+/xMckejMGjNsmuQB4feDhzJSYp0kd6goOeB2AesxShIU2dfsAUfHzKQA4/ugU9Mhw5BAem3BQLoLcuF8Tz3dnaBDAwnwfDGOwe+DITQKJnng5Gf+x5KZYLZSbxCxuwoKFTWK2q4KAkyHOgLgtdqnR6fHrncxcpr2RvxL3MuwBhRxywU85MOMyFDYEu/83oF5zUC6Sqceq1EDF9nY+kdwNPfje0AZsRa6ACXtnPR333e610WLBNN4RlrC5i3Gm8vbJAm/xYD+Zz5CfJ5Lk6D4yz71oL7sdzmvguOKeHFC6IM1QIgeWUtMaHI9yfE4KFU6RYSqRJIlTyqiaNSGnWK8Sed2Q0AbiV+GkR5xrMPQ8zyQcxryj0CjnQ4mcUjbq8X/wnYG/OD1o74vPXPJekeB1NI0wOUpuWAtre3P8Im9KfhvwfWbI5aj+ha05Og+iYNsnieDoPu8anlT6E2fULVTRTnMOXDoIPKFOJQ9SnjGZug8JEEUUsJ+SDC+E8Fn2uw44A6rFoIMwtBIyYXX5XmoTOmEYwnHdxDUdxyXPGBmjj6a8FCP4TBdMT9CCPou9aY0fJmrW/ag0/vix5U2uVJ6QDVy4KWkFnCbIBKrQGrBgZhcrvXIra/WKXDIfH+19P4CuFZKWwQ0pcdn97uWfMoHPpZbglNlNR5taIAziZY12lO3+EEo+Nq5KgVMxcg8ZQ2qxMmA/FIshH3pyoIiT3TCpMOtJUhZnietUfbH97B0LjP9ALnlV+qPlVm2Cwne1x6PY+yJBiG4zAYrQEwjePkyhf0SHsdRje4E/ypIW8W8lS/PMI3PpzLvF53fpgPgBYYC8Yio6LQwDeqxfsLlCfaIZSXYl7hB2rWYHBXD6TxvGZVXp4F0/G+xYsHcje8U9OAaikk2pafwWkSx2O1kqPAH8GoAiLHHfyr5Twlrr7n4qkjqTSPdwpTT0cF/RJK16LigYRWTAPVoB4OZL8r4zfk4ylhJKJBDXrjR8fcFWKepzpSUJeyaRAkrWdyoWDhoW3Ptgsdg3qJmFrQqAFqPwc4Zdw7lO5bttYNm/UmtoEDR/QPVIfz2s+yLe28GttWSy6Ft5CtLl0eK01OWy0qt0Mb1FtQAWhrG0T9YHvp2DhDEoAVAGpZCPzxcLYazr2CAm2j6nuBE7AEhoQ3QRoMg/A2AIQEHKNtxJiptWXdhfkE1T8CcZaZPC071raCbqPOXeKzoJz+CIDm0KMRYqk/zKGljvWKuALA2dsQTnwiYAFwoWk4ug4A13PgRW/g8HHFLnj906tTyZ9HYe5aeBNhvaVvh8A6whvErQaVZbdWN9jh2RJUFyhaCFspGODUMIIwQuIjYRI+CARRKkGB3DyJnTFw6zM/H05aqX1x2P4ffvvfe+0/XxaPnUH7ctFzX/SWtstN1C2WfRxRb+iWAovZBkOCb7jPETDsdFgP4qx1K/p7S529LfVUqvD2JRTBUtMmuHVv5dmDbOwgYe39QD91boIHz2hPfZeTACWYpEZWIWHWDnBsfwLWIBEY/eEjNwsMmIS5NEesOKsu7LcOMJ44v/9mzOpT4MEHtgt9cJ7aJHCJEY3iuwiE49GA2iiPagQI5NUNWg4KC3SIFQMehnCM3mTAG7VwcgcZTMfL3Sc7vd09+ktp2rAcQZmnU6+YkIv6SWSuNZ8lHsHH3TbI5uNxeN+yO3IMdkGtBwHOZEGzjZObDpccL5BoNVI/gpHvuHsVEvvFE1dELeikOwEqD4c2SFmfgKi1aV+BHCPUzm3AxvYrxTiCCNTZtZeOAbHCRuGf7+kmju+55Ilo+UkyDYEzyWPr/N3HLjCkERA/PiCiUQhUAe/ygAqNjHu6KuxDoO93VoZ/afK7NQtxfjICCAuSwpEK05CFMCRrAi+ziX8TdAWhscZAyIBVrWkAF0JenwHyfXH1Ix0JWuoyQwtL59p3Vza9HFdnoThYkZ+v/45/rry0g8NuKYxyGssKynPVt66gyk1juXHnLg3zoHVVBQUgoOclfD7wdISuBVtHtl4LNIU9TUvB2xrPgXkkDzfgQzNA/6ld7QoIMXDKTUGCoMnEfQDkSok2+BuEmhd7ewURU3tM/pFK8Q8fhRpc7yEtDZSojkjbUfC98pm4CpymeYScYqvad9HuG1jf93H+Jp5HI+YbC6ahNOtifx48q59fjdXZeyLKOqskW1OksCVRVfSPcBzP4HEO5+0z2T7gKt4JLwDF4SS3S1DeIX8R8EAW+UMStIqZcjoDOisHAxSdi/cVMDaf9bBprnBerJ/Oz/H2PbLO4Uzf23vmWnijhnLldI7b3EW24P6hOw7T4A5QxUrn0yBzi63cKeA79eKcwGpJt/tbm69mA9tHZwnfB/NJIY9vRsRC7u6O7UUNL7HscGWbACETWgdG6gYagaBNAYPI/NtgwDBZ2MBuAjEbAbRKP3n/D1ANQOKbKusGqDwBRsuz5/m4/YOt77gKGNx+qFMgNRTQKL39QslUrqUzSdqa1DMGyPIwBCAa/i3gLMm1eKIx02pyBgnRSh5YZSiKS6MONwsCsuelVdHbwXnv4DbKWnqTDt3cFoNi1n0h9H2TGPbE0E/8YZg/DOKbVurPBtdX7jCZu2hqgM/WExcHN4ARw1oL/R3g4HQ+4pXXNXizYOaRZYXdRdVbF36H0TiGkWqzQOeeZ4fXwGhIzjGPc5C4bq48NaP4o6e0WCjbIacAAPlWGl8YGwclOLSqgYMizTM8FVv2STA7R8B9G1ZTNYHSJRel623nYuey2GHBtAHQoewYATO62QiQm+RJ9WT7XTyz6C+iAuItL0yvI4acBoGspzdl1tW/mPVhAQcE2cO9Aj+GQNhy1k3uCLRhsRBb8aDafvEGymszTziHeiOcfrn9O6gkadlPeLs7K9RUM0/DTAXLwNCyWktHLqKpSBBmLAyzsOF4JELoBWFNUGcYRuLyuWAhi3FaTz1xvSyg4QxPw1mYwzzbbo+mp+fU14dZwfqkEOfaOK9Uu6ZqhUgbQI2eZv6Y1/pqDqJljndoYVSclnwR2HMNZLLaVs2FqeOuqfXEqrs2FNWcAh1FcQOlwnFpLsVUclnHelkeSH+lmtvGq25/NAsz0sGNggiE+r6mOPLvgT2wFnqb/c7OeGm9DX+ExqPgDj5S2/wKZzwYkZYpZy0FUjdLTOqi3DkFSipICNMWdfPT7/T+uLSwv0AqHUGwcPGLBeO7dsQNtfNgsptvfx25gNptM81/UZ0nvzL1hIayJZz1oiNrJhzNAh4z4QB4KSeanqszfIsw5QwXHVnCpOI5Zi2aZ6Df2R0v+zBptEpyDRblSVnK+f7e+slPR0CZb4P2PEO+8XoOLzILlaVZHiekkWQ4rPAX/bqbBBF9o4bQInOKxOcBvmcPHaGOmg2I4iZDXM2WRn2tbnkH7fRgRzTsFfoml6w4NAm1jNLEKeqtHlirbsY32EoJarTQZJWmRSwv/JNM44cZyJR9VrEv9FZpE/yRJwZh4OTIIwXPgy9zYHAz2BSrutbpIQwEaTsNQy+QGn812SYc4PQVIwWh/C62sgnad2aRn8ATyAI3IG9YPnQ5526TbODTZQPeBM2Ao7BIYB7NU3xB+jtEePjR0a7zxtaAmR/omoReZsNJsibRWXAzKIParp3aVaYUBTeU2qd1dzAxqg/v8PxsKiJ3eXxnsB242W2nWRQnzUzmXSA5uNfM/AiO5EX6l5fN8jn0xmMoF88un7bE494lsVMwcn7hvNwT9KhZ1Bd8aDafyUouQq9TmffcXsEw7Ljhjle3GPu6iImmMPhm1w13a0sXa5sD6+rlu22EvNsOd9QXrABY78mzUdhnwVNrlLdHofOEfnVHOXPNo/xlzzwD5YUxA7Jeek3IXFJjNZHj9ZuWkByLwt5ciHbFtp1nwQhmZAIwJvF0pNHOUl9oh4rNSaTTY9PuDrH49Ibua52C9cQvHn3p4O8u63qePNPZWq0MvSgVUucIlVOM7f9HHCUOrMJS0pyu4CkfwRiqc5ZaEmerwt5iEdp1Zm9OhXPg7kr7SpbukIGobWbNifMaYT2GmUDQFfZNdMLk3wjjpUxqLep7pyCxskg0ox1AEonhVMFtzoPWzRulmaucCAc6VTePaybiOCId+JDUtuFsFoxCPPVoENQ+qqzTOJ7J81f1rBhD6ezUmI+6zsMZLPsuWG/n6/qIJ77sHe1L0mzg6TNPjN5yM9qcSx5B3mCIG8okjqcD4q3kSQrD0azhV+zpCBDbuMoXeu+WVt1FZQmQb7rYrmyo4ia8VofaMDF8i1V7+da3FgBlCUc78Ri61hVVRUEu7Qe+8/bqL8lqwVozvB+/YkMI27iARvWTaf+/Hq50FAgzya+NmOOtbxyKAYkZh9dw6Iy01isLcg0Ycuc/1NtXmJ383ZZCTcKqhRAdVcYc33nW3ubT1rwYAq68L4T1ftRixPM8C0dB/TKYLdX6p+Ah1aK2a4wREPnEBpFr0syXla4wUmsV1KsUTlU0c/mGcMVMOs5aNGjYMdq9eXXxgAuqsTLS7QIqxkYuK3rTEARF9Hub+LAZ3MLsyFXnmGtJcxwXRziKh3Nky1i+pEvLTFvL761X/nQ4R8NR5LOgH20+zFD3ZvkpsPTAroRDuglAD0NhyYZyyjTMcloBrJGh2nboRxpkoRsOrKtwOiVLt3hsxVd/g6MxE6Y6M3RxlHvb6vZY9Er9bFKIv9IeUkHmfhJDnXmEV/PZoDDLEpQO+NRxeA/yALK8z3aYKa6Ubu/qaK1DPth9DIUM8dI15lu4fWmBYfm5hebMuQV4L4Dz+qr2q74oqKyWB5Hhv0ZuQmzLQV515Ky25F0nPNRgTpXbWXH/oUOs27j14zwr26ro5PpqngNCys/cqS4bWmp+qbE0QWEAeNaa1LxjfQzU+aG50tFA6q1OcLyk3MdjHxCz6CLskfq1eVq3EzvmlYdmeSbRtmp51d+qnnrEJEgoynDg8bzB/uOPLxSmvCyQgqQynP2N4ol5FbOPFouzGquusrwSAgOGPepAl1u1YwgTZ4VMYcoROJgwEaeYJDDGxQl0y5MHniqMHcBfrcYDqoniY+dqhCepIQA5C0psNR4C2j6RaB7cT3yg9sSzsNscmuYMiGqStqHsN4efM+/islhN4GtxVMo2tHCJ0wxombJJUOq237aASriGQ6RmGw2QPfzLsLkSM0vvw2wUXqMyhmZt54AujPCLc+C9eP782XM2PsceCnaDut/nfzp+kgTRiCsYV4v4VUwHGzrCkqVkI88XrrjUfPOK3t/yii5EXdiAJwhGwqbm2nw2uF7+SLbCpx/Ozj/ajms/gz/uHvxxn8Mf90/wx93Z24OXO/jWZhWK7tRJUyusIOfjuwF3xGuNty2rbV1cQRddqz0dupYNn1GmfEA2iuTT2MqHCZri+PCSXL4X+jiW5KiPBFOaAmHDot2X3VFw243m06m1+/K/7Vh//7tFzqGXn6Nt6qQOyeil9Ejc3t7+nk13mNxuJYJBGMgZ7ltjInrF74V8XG6xXfsgyId8Gvap/a0smwySO3+eT8QLkArpyASBLJcAcUUzXLi2xEp65jawINtbxcObAV2Zj2RFxkx+Yy8IAZY8qmwSTKd9i+Ir4KRvgah9gx2cJ3ibLzojXoq2UQsK/RXeQ/TqSzCbt9n000c7LHo5nKdTfvDbQzSqBLET/WjoHTIfCT+GCR1mu+IHaqOydgKrwAVFxAftGT4m9DvNHrJpzOXQYGT3ivikNqIU/xuh4Ug0CkbteXKd+iNonY0LUE0kxoN36DAFsCRdGBb+Pxrw2nZG3V6vLTyT0al/zFMZpELZActn9170ejyZ5LqAirq/b0lW7T2szcgCIBxLgs96f2T9ePTmw9mRYQMGsnfSDoGZa2EPSLnNgSnGYQqcjiBPuZUFQeZIpu1UmEYcAuZA06Hwb3gIpBXPKfY1PwPkeBdfh9UvR7Mkf5BQkPaJrz9fjY6R32AL2BJ4VepTFpwenmhAT/x7LHueorXcnnhJLb9FZ4tzDITxrFcU/sgqhsza6fWf9fov5Ke/7uy8idM7P0XFutEeWt+o36+mqMc4xIsg6i1MkqVgaB9fIdcNzVnPyisu0ab7Nx+VoDK6Q4fM62tXG+hZ/WpfvD56c/jp3bnUsANUCvzhWTuTLeVRMZLverMtdT3LNn+e9VyCQhSQcIIIKcEIPuepOkGJ7nkWlKvg8EM2zHEof/6zRN02SDWolouum5G4cVjIJ+BJ3gGqO8geomEc38Dqejt139PxcOfZsz9VP4bDWTIIhpN4wKYeAyVdZg2FZbn4ep6xrRY6VCTQ37rGcVwd4DA7fP8zYLefAVEWr1dbWtDQR9TQ4AOTTYJCthnwdcURcgaEaqOCaYLkC9C9YRpk2+vKISwgn4MZ7MHQjyqz+mKDUd8EaRRMOzdJTsvDnPeu+XE0C7Lr4qtsZZx1snk4GozmswQxXMGED4WmF1EXDd8yvV7xOXuYFV/L+yAPZqPu32BdI386EnOjbYuv2AwX/52hyb3JHo9AWYAyeTu93ol4L7hY8eE5vTd65yc5/i87tduDsz8uDqlHderw9LzfB3IexqNw2O9/oqO7fcqHdvsdGntZ2zvb+w3FizPyEzfPhdN5NJyN+Ig0GDKeWKAxgjJZ7XaERs3ZBHiqgr8C1qq55KhclLmwjRsrMxy/EZxgJH4jFHmWPB4M7g3k+AXOtiXObgoJ7yFFdKr2LXI/ZUYX7waDyGJemqgD89QhkHNgea/3jU8+WakDIbyO1Td+t7vbRea7zGF//PjTPhxu0LVFwc0vf1M3222Q1IaBmGEBvW4Kcf7abZ65Zv6+WpX8mceWjCNmnaLLCfrEWG/SIPgMAoH1kvfqLM5HG67fqj2gFWpaWPSH02U4qdhldrQ184euJlsXTnrv41dkwi7KC9HEavnALYKoiLpCjBJFjtv7VuGZZPEhi5HJfhV1+7+SawzL/GkbBcjC43IYjtJH6l8KfSG7sEQoaEqn5iJGkVMWsoQOv2/tbgWAFHCQ5MSvC9otjEPIf6mvGKmh6BmIXPBjySJOkLdZRAI4fMSMJsNkTxeOlNqwb10stBledhc45CWTe2INMtlaG0TQPloD4H/dwibgNvSheVOvtFS+WSw0KSBGwzA3Sw0HWFDBdTNNpgtRvoQPuvEtGePWGGXvEyJ40tW7iy/53XqvbsPYOhjpLt2ZP82FLXXWyeObIBpMgvvWD1CHxE0PPfgvbBYdp7ZrszgKD+0X+BfWt138G360bTXWS+XBsttzSr711DD1pGsrXLUN6/GNVCFrrMpN8NKoXGsbzQ5q2ibNH/I2WWthg1yX+9EwaIcjuz9W8dSEkbhrk7jRlh2z+0ph4Dy1P0c1NkZSGzrgWAzUEXP321KXOWCFrncVx9OWhi76XYq8RtHdEmErq4voAkxftVoz0WvoVcMwyMxaQS1M7tUrw/UhzGIxXsJa+GlvSeeqO/8BBWyKzkEGZxSXME59kK6IAJKo3bHOgnmGgqWPym68O/j4QVgP+BHr2dN5kgv/7O81IxwK+jgN/NvAQjObk8NX3ePTrsRWi72b89wfTgK08hN2iCDc2RmZOfxy0pGucwM1kLHdwX/bi7oNtCxGWA44ICx37ibhEO3DiKoTIo2ysqEYcHLeRanIZVnTrC8yVHgKNYCxMZHKJd9SsTCOCQL3ONa7wDJihA5VqGxS7a22fYrd/kK3kgEqXfKJAUz2zNHDkkNrtLzsGG1+nt3A13FW1a6jjhXB1d/VGBPW1droCoDG5Q2qlrWzVTc3LDVM2ifv4jFT87R1YU69uWKsq7y4dCorcoHDA6oK05rMc15AtTh2+zaGMwIo0Kvj14fnh0iL/wZvArRtbKcYu/LyKfW2dmnkBDI4jE2AZdm1QL4sO+tVvfTqZv5VMY+0cXGH3vmsnGdr0hHwkikKoxgsggQljP6R8lUhBh+YwFbdsX4Of3S02VeEXXRP+Oht1bv1UQmcqOY4HGqcFf+sDbzsZCTALDbCttzcziq2M3Q1xt40yDhCEThuVron8U0jBpsln0ZlqQMSqIBgjeKAp5QAoZdbPqEbkJE0QkKcvuLAo7dhmk0ALUj2Ip/lZmp05WCjFIak3sZjcbWUdy10NsKSjTpYCPm1edIBRpr0nh3b9MiqsS5ae3Ek/WZFe1RP3h3JE+t+NtUmW78f9jx5Odwv4z3frK68ztYvX8u0ohwr1RPtVK6ux9sHop8vD5AreLkQ1ZYHxMC9PBizstQCzA5Uf7svD2SIAuQG7QV3ZokfpDPxy20dETkqroaJkr0XU/O99SsrgH7Voh6Qqbg885IATSMwKPI+XmTL6MvvD8+NZYAtDevdMN3iCl7e/j5iUUyizwi7GhO5kL49TIMc5lsl6sMQ2uTD5orOXLocyYpkHYNXbQgehX8A1zwD76qW5jKccocuEM4lE4O0pGXf2e4omAZ5IEQs9uFWftMAEtluoBXeuEPhFyr+pNVRwZqHUYCMdz4pjuFnvfK5xRQQyaSgd1hBQ9gKYNRrkdyrzVkxT/r0oaN0pfqGVUs7ZqvRtkwP5VDZfwv913fpcp8sihgd8WhR+1PEakA0HwgabLrGmgMZxez5SFE0NkEZz+vpTeARGpjen5UGqMyqFnaeF57o5TBlhhvlRe+S/URLocz4NnQe3UTxXWTzHDDbD3z+mt6FY7xOXjMBFQfPogu1Xp4zD+NrBH5KIUxaF732n/32+HKxu2z9U7+v/XQWz5eO7SIAF6ocGzt81heTMutcg4SftHacepLIY4Wp0IaKcei5HDAb8ZWweOYoMByIBvVZmiMNIlQ1IBIZ2GK8GQ7Gg97lKUddImEENp0eV6I2/lXtpKN6gScdxWq+4YBvpDK1V6/DI9eiZj0+j55+7hh/OV34i9ehwojPlBVJsQ6G/8vO7p86df4v9avXbFqvmC9j+nApvGan68JvBHpJOhVyEcACzYGZKjYgoqsKBpZTpk3NPTYwUUPF5lBWZeRk/IqEjRzlJkALSS2EVzlCEa2Giq8EqFmxq/zHoSERo4I4ollvrzb8lprLumBbtQZavzn4VmWNV/t01HXqkbuMpEyFQejgFXTwXhl6j7vunw6+u/g86lw6QAM/jxY77rPl546zgL/5B7zu0iOQxX+yXWq5ZlcJxaSnWpLmTl0MhHzRu9xqCO9SZwMm7YfrnddqHWuY2zwes4oGBVwZqAulwMImtwg9N+NYc3QxDrIfyI3k4CNU1XXdVSHMENcleEAu+f6R3RVIKAA9Yk/XnjbK2pNYRDhh10onmrRQmIpiGBRPagbtlwcASK2tTUpylAZ4S0oOHT5I+QI/okwxFYCQmQ9jEiBUG0KEYMWxV6RnoA1iCG9UYqW4VLFKXSszyeQS5v1BZQZEsTUTAHIxvOR+Lu2KNLXBTHB0thktGhE8dJhBNUYIe2J2RT9n/j0+3g6TeSa/iV/wiYJtuKRgR/1pEE1QcTxiFbwi7K+JM7T+evKuY/0qy/yKI2Ovqba4IkdznXwe0TUe600wBQQlvaHIkkJHmUwFNLle+JL0XlKEo2w6MMFsZY7cDmE0OacHM4ppl8WciQebITMhCgJJwZ4KpgWGCf0JvDCmf/BMiWPkovPUR6noS5xJ4ii+edsHs2AmftCaTLXp35Y9lpOgew2fpjHSA+4nek7eBeH1BFBwHmEcP2GRT9fp5CUeXl8H7PuE3uLoQIz+ARHn+kFm5DZQ9vMd3ZeUxjLe/hxZ1oH4CUiFzgTZywVHBEA7T7XIjvPk+c4uiO+izEFX1irCE4ZxkrGHn1uEpVeB9Y8/wNO745NjDMfew8wB+9bsalWNkx+LGntYwbBaVQay0gwYWu/zF2l0CtuKHQ3xG0bTebnAJxhF6fW2yWBfNUO6esgDAQqLFXG8FNCixHbFmBbACjSyD/jhpf3UFneLVMB5asP+FJ80xMAr3naCZnd8YqAagwKtkSecFs+UVUZ8W6BvGBMDNsBU8uU7hRbPZIMepiIBLIHjLUO9SRgDW7DTI5JSgNEQIpIen6XVBXrI60pLjH6mTsk9zTzJbq5woz3Z2X1e9rvDzQdrcwUzcReO8slLoKMcBsuHrYzewvbi5goo49U8zXL68WSXCKiKl7WuYLcALrcuUE6vetxtFd2HbvVlOfy7sMXWiS9wmFT0qfm2crN8wFK1oOOoSH0JRYRijS7dhFYN38JCxOkD+g3BKE7CH+2Xi4KEL2mh4DsVHc5TPDdO6msUZwDUMopSZaQMFg0KaalnM9NjW6IkzKBxXCwBqiImABCfXy4EDcHb5oMYiAqO0EJxzLPvf3gxeLFny3xjnv3l2XP75eR2BvsMSr08uIrjnM+/yYjWCQAgnHFA2c8Amj9MQvjgJ+EQv6sPW0zzxGnJhw/IWPkEJIXriS1ivWOeGDxEqTTaKFvxeJwBRtvzfCjewzmQoBUGfHmJwfLS+AH6ob3EEmmAXX0prCnou3iFX8nHyfjIbxA8jC4ccofxF3rkMg6gps22+LNHXtuwL0dpiMcXq05R522L0hzoH44EGJgYFrr3Dv0U9u88mvmJxlHQ9axN3s2E/tAtPFpoom9HPm6QTDvNFkyrYEWxxrqeDkcgpqzqaurfVfuCrEWlL5nqS4b3TfAV1eQoN+JaF51Z0AZke4aDIZDMSHFEgPH3toJqcEmia3F63cHudVh+JfmvwwRPgBKNCNonmsnIN05ATPIHrACndhZPA+Mll75O/WQSDjPJ+hZo11UIAI9EA14qYwvWfw749Tfh3DRejWDTsfHLCet3m1g0NgRmFbDOlnFEM9alSx4szBVTZUbERj5ZckN0dUO2HKwoLU4C1EL/LoyqfCgOoW+k0r5PygrtijxfUj4IpfZ9YtwsKzWo7Gmj8C59lnmCdW/jGk34veHHRKHAOX0Bs900yTKCrlsTXE9aEdBCukTAdKa/2aKnemu4X5PNQESQQ65BxArYR87Vk+Gj9i3REXojQyHo8ltr58DjqgeeyEW1KjAiclIU/AK5qJ3//I//tRCVKHKAXQENnWC4wKivgot8fBUuvEXPn1S5fkrIMmnVgSfGxI1Q3IcVrRDRVc0sJJSlbI9+mANZdSGw4NgifVaC4ek+z+x+Vb/v2uJ22+6zQszQOvXXKf6YYlKUFZnWA6NzElcjMtQIozgKopGahmDiExqhNATGlBrr2uiT31uvY5rzDDNL5KRhRH03ekvT5ramwTiP0f5NxGqK0IomSLt0Rgej7syPMJByYW/TkaY9vB5ISCgeMxv+sbM0U0XB1M38BxDUwumU5DpfmDGSYQ7DitMENj2QKTKnSBwtL4qiZzgzLk+AK0dcip15KRddwlsZd8M+C8YsQ4D4IIJh4Tyo2iRzohk+nK55K3OYZEZx0zj7pai1pT9PrcLGUjbhrKnQsY4pMQWrfknWmVMgNRgMLnTmsnHuDDreTQP8B1/McG3DK7K3ghW/CsYYdovOMfQ3Ebtjg+Cijp6FRd07F75rSBmVoRXaeRjGUvN0ilH9Wjs/OEJ3kAVeUzR1tUkGUABQ4Y0yBKXVr76krVB+LTGj8sG00xJHqiSuGMRFjz1jDp9rjGOhRVemFq7NF4h2W9jxkGMxG/PgUJ16LTodduNZLplWQ8AHgOaVY03gYayLbWhuzFSPtdRCLz7GGPG5UIlzQxtFKS7E8RM/vWGGBxAND12aUolMYXQbk6GBnA7UNAW3eLFGagBkDkW8aLG30Bl+GiDWa3HeivU+T3VP5PJMMwyc6zFau3BaL7v9xnZhNuDhSpt2ekLIjgtktrTWy7d2wXfs6DcawC959vPd/vO9fq/Xt5/afbFZx7YyAkxhG14F0/iutfv8hdPv7d6DOI3EalBEyX+mK3HkWeA1O9qrwhqeG5NBxsGNhsdVo2MdorZJTJiNsZ81kql4T2ODYLZLwawYkdvqymJSS+RjNLQ6jiiClzwbiB0Mia8LOQwkRdn3h4yTvgysb02CNOD7BDzN2NzTiMChyDaudJcM1OjKAe9vOQYVsvEz1DViKI7cvwlEYA6RKuPEiD+4QvIgZZiYA37Wxq/IZyF0mBeaJtcRA8dRn8/BNaPf9gV1tnWZQL6XbWshb/vYD1vrGL0pSppx0PqS4eX3QsNBX0obyJUXFwPULdh9XfFfYozUD3mn6try9nJgFORvgskaANnqa6mDiDNLaz6QcRF5b5AVBAJZGlOtHQQG8gOgeAaN855SN4rEVjSZzWgmM832Es/MC1Iqv0oWMgDWEqVVkUwqvIOaXKA3zSml9PQTFRA4BRf1q3TpafAbKmordannjaoU32wJqmS0qQtVe2Sz3sZ5pqqAFAedKqMSScxH3SKdmLiq9DN5U8PK6jskWzKiLbo9m7eeRQ+Ne/KvF1BIrWBLag57UJ4TDVuzicqUCUk9uViuuVEFIYHWuS14AEz8wsnTRPIW4hjIHodIpm6qTeSTozrRSUE2qBpkPBgyyY4IPQ60AvsS1TCZcNFHJWRna4WhndBpbrqt17BNNQ3gtRarPL5JC3hkEU1zpWhCclKrYKVc5n1aJgkshCa3pfMFQqYqR/9CKeouqrtvpyGS1bPsgLM2q4lIplIaCpJIxfOYDQmj0XSWp0HQUvKf8D8XGQqKtJZKxJNZNvJBgdaoMC3OcGBb1uluNrE7qmpudAVHVSnzW3UyTcIahbtXFk9axPsdxyl9LEU+NYJtOq6RMUIbp3lgBfnMv58FM2E5BKyxxgYtT0gYEl4pVYtVPiMMenMp5mm/nNCkwWsLS8GwRnj9sst+WIXqkA55hQBqLjQEQF70N66+qaArLbquLvsqbVnTapsraaZFwJVGGv17rDYplsVio1iFY9bWGB8plOx8Zqx31Q6Y177Az0ucq2+46sa+l+xrsfDWt9n6+037ngblrVmlBgpBZRqw5RWPhGiEjIV5Bfx3EKAfDWVEoOr1Wk+NRfjOs2Fxye3JNLC8KAsU335LCk5ARSNG34RrH11M6Nwmz5asFJt4Psv25UWrdZ3GdxjqHS0mJ2SukMlskiTiaVkFOg1UazXJQsZsU9r1u06VQb1q0Pj3IWB12GseJXV0bhO8RUq3Gm/164HHkp/qMtXivqfh/uZtEE6sZtcKoiZl7G9N1hAd8A4py2O04OAAcAIDat0a0AurzXb9MAZMk9dIl4XCsGgkSWO8DKxrxP75lxO2NivbEnyO3osgBTI6JZv1iUysnyMMRd63SGVnPbX48vlzxGbNdNvcl9GUPkeHUspW74RPwwCtaQeFQQpfaMscyfRDdBgH+nWuDnI+yva/zaa/bKOlZ5Yysl0F0uDppVdEEMwudi49j7tcazC9sPGSHCU3LNy7BCRl42zxZhfezPyh/FmkghBt7ZXVIRUzVlxrLTyxmEW2sFxLXYRJKeeAoz3enNB2lXGpwBpRRubt1UxLZR4f8pJWahjyaWsrRCAs5x1fGLPT/LlF+NjCvJ0bI64FDcHgmzCG0InKhoQEOobJBS4UqdjS/K0rnrm1u1ouAt/c1GFz8zpwMVoHYd1Rtw54bbFq74jG9EXDOg1UXa5ZYci7YABLqjlGY7PaZcNEz1+xbIjmRJPpfoOOJXwl7fz/8YsGR1X474EuTLJhAJ6o9CBvlDaI+qHPef0tdc2uoXzOpalez7Py8L2Vc6PSUXBmAy3mat+4EiibK5T9b7+96Gt07GAVj63yLTTc947mQ7rvnXByhWEQToWvLN2QKydEVPbOfBEJfN9S2avoQphyiCIaoE8CnHchXqqLw5BSbkQUvEC7aP195Hdp/dAszX1r+b1wv0WMKWtJMUWzNLMVFAkmNoxQ9UeRioGLdS0RmRWnHe+GLUq9zAEntfyappJU2ltWl17jxV09/0YppzSTSjTTFaAotZBYAYk0q/T0JQGCAa4WINap+VYoQ7aKNEb1+7DCwP8+WojfRxPxlXj7zTQR30bQKO2FbypWNOpL1CHHp0w9cjRajGlIssL+6huaX2l7l5NM1eCFdtNY0lHpfZYDPjDgbZC2xKD5agycsFoHxYlz8riU8wiGeYV20Rw4CGjXLTK8FHuFQsh1yVMYY57MSVff+S07Z+VRgMRr5bZSeZLU06rttd4ajWxE/WwgMNzyalgry/Msk4EordfLFesFxTT4NT7E5o6azHM0HVolw+09d2pz++nGGT2nMblfzfhEtPeFGiSwp4wP9rLPXlTrcq/vOFubtaXP5VdcUr2o3hrjnOvhaMpGNczG2Ka9zFo7mYI6lTfwpaQmTWW1k+4r8Pm3YM9GF+0b3mN/vXKnXqgYfLn2BxT0XSr5OB6naxUHQ6+wXD+6D4bzPFAsZ8VLnC4+9zlqEIpr+i0riE+3uZ90RfyMImCMSGhHBE54K+YxR3NFixxMT4Yh2rDrmcWKEpEkNcQ8NMDzcVkZS1SY7Shr+MR/QFM1T4/ApybfDnhMdt/m+LH42y6SJdvAb1Fin8zuL2yceiip4uOjWiCFPQNC3VTIi6IXzqVrAwVGlxgZaosuyJcMeumKSJx4mdiiDBJ925FxpWAS+aLRNOLHwLyzJC9Iyg+6QiiNr4KS+ok2HCm62qJbgisQU7KZrz0CXmcZWOP9zLG5jYwnBEnYClYtJsIRi3eipjirqF3bXSyl1304sp1q7VHgY1zoQN8yT8nTskenmxhcTc27Caab1KodSFj15JptIQYSq+zFtkCh7f52gUJtLrbtbisE2u4vtqH32/0/jpZL+4/wuAL+pitp9mb9gpYIGVdfFZ1oDZ8jAMCiAsKq2DAibRB/0IPGoPakMknCWtOu7yXZl2tYZAB2KljSNFLSdfiS4sPRhDYrFS+YVadpB61nG939hQJ4cPVijzRjRVvwVkTtE8qj2rowfTV14e0GdXGR0f70xV4HQIwCXMiW6IzTEb9FjE08e8mx0CYrNlHKyG1S07UqeNHfNeBFqZXg0yELDMbiIMyaFKnlpMjDlfiKur9w6rVKqFlCyLFtnh+MG9YixcSCF304AXuXj9kS3Gp9n8UJXA5buy78YeWglX3FMiMEt8bEujbbYvmw0R2aqsZoekmjd4qsl6ZZJ/cGAaiMpj7c2veWdlNDI6ZbWLSeBT4Agwn4U7QzjtFPW4Rr1a24SvZXxU7eLRKqFmMqO2xon7Y2XhZzIFpsHqR2zGLBcXDrVrmrlapaMl5nDxU9lTeCYiKO7y91rS7VqIQXsWXGAEIez5Y+IdlkGtx3vsxj9K3TGiAoTtWJQYArc4+SeZSjk2fuVhNGYv3S5H+PKeLYUA/DVGbBeD4VWdIxw524rBnJCz/BRWborSJv/wSjSQ7IGtxaxpIchHDCEIpL+fbI7yANZxgk+F/eHgofhCv0b8H4mAVGKdtOGQPMiClFDiqU4U2zdXfMzGqcb9oIUphlE6xdjmyVyZjZlQ2sarh2OykiZbv4Ht/hBdNHisD+E0zAz8HDK+QQUCcfxRqfq8BRhU9ZkP6Mcd2wToY+mZ6KTy+BvoqjCKb7XIo0vRpoYxvzUP3zIkyWNkfyFjhilLwsY0y95kyyLNlkFTeqZ5ODkjUxwldqbXg3M0eHWMqsSaci6vSthcLe5b718eNPFEYFERc+tUTTZZ6o0iE4X3Z+gPNF13tu1C8jgKvWlY7RFS3G6XBCqSkeAoqhyrmZMa9bOp8G8vaH9Eb41qXEaq5Eb0otKH7RZ7xAJBduGf5P825m8Y73Z/v4lLahNaFYvRxh5TVG/8Rm961Pb/5CT0C/0cWCkqGNpDcGtVcfVkwFyq1JKav3mbPqIXehhuZ4xG0UgzHIU+v8IeE5d7VcxU6lZS2PZTTOB2hT/NBizxH3m8xiLMi4H8541nDSjKSeLFXjRGXBlANXQXuj+ZAS32YyTmWRt1NNJfeTY5zRowOs9V2QttQN7j5n1uOrdnyqlChsBXEonjnF+1YxytrZhm3MLRdqLpgcYh7xOho1XLVRoTCYl6goTXugHiVA5YoKPGcGVNDzYYL20KNkJWiqNIynCjgmNwHgWK/in6yGqydqhPfFWMUHp7nFrMFCieoVTW6I58VyaJ3oVy37eQbtvsBXW9XjRAOMnHYBQvoZ6+/DRL6ViG3fzuy+QGnXZg8dEWerLahBiItATYwiH30ihLmF9G2GqcVK58qFATYFRsFMSzly99XxfR0rTEfWMNbcH7C3HXvZxLwVGh4849qUkRv3GAWMm8GG1q5nZcq1UATE/uX0Y5t4UexYW5E6TErKdkwdzR9XGw4t9oTcx2Tu4rQtUvdqw3OZamEYIH7JfcLK5P9bGSS1JYn6PL0OBrgOYybuWSkG5Pu4ICgF7ZVB1MPIJBySgu9TBkLmCOeJfv8Mg5glMcbMUgSmiY+tms02OeOQplPGj8XQxXUO5vks8fBVBw0yB9kcMOKeAhB3+Pmp3YEitiq8ubq0ITOFHi1ez/xhRol3OQYyD5ATZw5kYFw64GgjSdMn3FOCphVrdIrZbmCNWFVCyx9SWDJhAwCnwBC1VoSEMutS7l/j6anO1M4WgXsf3DGcTKanwhLkUE7ZLShOU5vSP6GQT6Zn2AryEZTlCdmfD+iXL8BsyRgepIilhJAEEtHIcP4maxFApjsK526aNlDC1ts4HFGCUqkFRojEi+DmQ5acVD77Im9GhsmoZiT+ke0taew5tpzEx46cwXWmZPJkEufV+iPxH3RuiXt07fioB/lWbf8NjpBNvEoEbnoLnBVdCNTuSXT8zVgldXHpFCJofTbje5nKeGnOoefR5PVl05TRWuPIUAOhvomIStp3vi4xu3TpZWRG0xKvueRqj78tqXQNaqyUtjQ9aVBryN54qvLJyWem9J+zMdwd1G/jWk7bt0nGEc1RejNH0kezSjmK5ZYwZP9xHk5HdCByUi3YVdkQ0BPEESIFEtdHVjSfBak8OuiqmCxi8iBNYnRKFp7wKrWzpgwoaRlKMyoSPFGrXgo7LQtyqx3Mt2CWvtssnxvm/bS2338YANXY3id9m9XDlG4MAysKxbCRFs26BiJrtb+Elv1vH+l7X5Af2wAMUAfH7w9fnR//cmSC/94640AVfHjT4XcV+CmlCpmnGKTtyxzlkPQmAAEgCu5wk2E5nM8rClRCWSi2cHbIbfwPLa27XCgopXOz/Lsby+5+rwj1yeH7w7dHr9uYMLt1cdHPEjg5+peXf/+D07UW19n8qtW9+Hzx+fKy625vu3/YIX4cFs/6w87SBoAUDrydRhikB3Pf6gnyRGiV7T9gwrr69HdbI7xVUoFOBpS5e/Du+OP5YCAgXljtCGAk29Yl1tK03kXyP/iM2f+2Vfo/u26AttaLSnVgrB9TnfpdLPLZ0asP718dvzt6vY1p0oowgMaIbLfAcqRY27a9XaPTEnE0yuq6C1vc8/EFH6F9oa/4c69ZuWWoW9lGDRN6xymdWbcBWRsHGe3hXESpSPjcxxMXywvrtC6K8hjOnM7+xA9TDe40jhOKRypiheE+KJSg3YqK8gqYhxkyfVJ90PmNpExxI8LYNpzafaQhMH7Unj/vXS63tHstSedsJKu2uYw20Ruoy4shcgy0QC5o80YXOT4lU0EwWjZTkkplVDXrtKBcQKYwIGWTun561CTwv+a4GXrJJPqiv4taHpFM5Z4QEld1nsgYGMAyrrO7Xm85I++5StYXDda8ZJBUNulFtCYXW+rSPl1VsO36+oyAW/UBVOLoNkjJK+RDEUGlsPwQk6al+0KVWJ07SjjTJw476GqyzdqIaBz9bM087ltZOtRmQJ9X+LJmWn+krpGZVmVmV8RlM+MbPWIGoUda0JnSDDbYfJBS+lbz8qqKXGXK6H1VAhPNqaWaD+LfXp1++tzKPjv9z9lTTA7h2C6qfqHMSSkhR52rShFEucj04Gyc66EKxDB+ky5VrhZMBqFr84fFcKyDyJCvq3MFBemaO9O8DTCSsb3RvFFRkQl7M8egmlnOniL0z9kTmOonlBelc/l0RQKUmgRBQt8KMzUGkaxm0jcMIWD2Tk4idOui713K3j2yczxHuJb0VI8UG/RPDJKAiKXGDsKZPKzdJPW2dN/ptnTlo7XX6cmo5zRwrwGZNDNs+nCg33KUYGX+LJkGpBvxTo7OD4motWro4FO7A/BkrtD4rmJdhjZYYQxntLI6QsmnAF/QPjPohKqnW2lo1WiMpHVxVsaaqDRvkCEdYlNeVRwMBjW64ygiUcaRh/D1UjeEM5Q5GmBdqbMBGZG+ZqLjjUs0yj3oU5u3jizN5IZ67MJX4lfwX66Bdvay621SVBjVxOhcWYRqqx8KPXNAHIpjgnb5zSgkDSnxUPCazociPk4yzL0WguzuBH92uq1R/oQpqQ7HcZ7s9GQDGr2FV+QCQR9dAKXoKseNG6A5M6AkaeVoYxXbjfnklTvM7mW2ZDdRbvUKyq5ZVtbw/8KQQERUlyZjYnuIpRMQgKaoGEvAvRMX2VuDMxK8QAj/IXNR9+ONwlvOK0yf3R9e7BHrMwFx1CwBj+6zF/QRpg++QZVM/yitcI3o/YgE0FY53r69wLfLUaF3ogYJVWqL0+flpCiPfcDia+phseXM1nqmfcQRLDOT71ZqCHYpFV7pbOSGW721AcO3XqOzaZgVQIZ1kRX2jWh1q/2EqDhurCpc0+ZeBN+tFlsZWkN1e54B4ve4Z8XpuKMHknNUiIPBZptebj+vNppDVuUQZwEloXskkwjLmXmLZW02pFm2Ig8SnUQ37q3hEw1i1+U+wby4uaSpvH0Uu8K5sQY3Ifu0ICBeB/5gV0LzER2uvCzgSaG7BuQ8wmWz3aJNAqb9NJwhi3XVo/AVpbtds+nvZchYO7N+5bZ+RZUDS9SYmRivBjArhSWSHKj7ZelaJ+LKcygzCjhu9Iiwjsmn6qDVNses94pwmVG1+I09nCuWdyOJ15R2VZe+hI+Jmirkpw1C630JH20M/UXnjKB+kwl0MSOIGl90VGuzv0SjQaQxeVpt8WpV9RV7YIPwdVpeJ+KWgTeoss0FGdEdN9Y4ZRFoxCcjPi6pwVr6cLstShPz5Bkfy/onPptrqCQVYj5Gznm3pXfgiYSJXEwBV4aF4TPf5G40p4K62HlEPYkvZaYUWmcuVcCEtwVBLkfBowD7BXzYX+iOQASjL/eea7Ng2Ve7z7UTTJzbkiW66guOSno280aVI3KWZjtGQE4NcjV2n9lFSpvRH28vignGKS3+6nd2xkvr7Y9orTLaFmH+8Jlz/IhAfzywuhCA2Fw1ZKj+QnymOZBPWg+Z0bT7zYxnKXIhhixsjkDKfh0ixn88A3FC+YL0NcaMbS35fJLfS4Er8qxvGmzGeM/NITlUnPEEDuJJ4E/RIUUj8mdwjivbhBEelBkb4tI0Y2pHpOgU1fAqzin20SzOA66SBdNxm0hgRw+bm3Pg9oyNjTCN3gSTSwvzDfJtQIX3LydFri+MsATtWzEbwFKsc3J9TPzhjS9SUGu2lFXdWEUrvWVaPUo1dHxTsju0UT0IHCZ8k5FjuvLoK5XE5jgJiN1vTKZeqkMczqAw8+1fxfG0VZtpulwVD6IBHERrahcJ1csAVoS/NQtqaMvJ0QuzMdGkTLD34cO7citlUyPNTqcuGGxRe2kgJ7IkGmrK4MKejESzX8e/yzgzjh4PGXPLtcZT/9q1MNEVK2LgvT+f5s4Gx2/IbXbQxuOeABXKZRKtqdHw6c7lmoOxydBU5d9S3ZO90xkkD4cBvAcSb1dedg1efTg5PTzH0AGDtz8i889BskRZPC0qZV+dfuKCxB6JkkRvK0WJd0K4xhlY3luaDqUpO4kWW5oykbBtrlOsOJkKSG9HG+NWsJsnvdBWqXHRYfb3V0ttOnYxXDagbryb/1pvzLVhTVa7au7/Vj9NNn8ohgpzWYzUaxop3qeJW2C66hIp8Va68zZOAVtfrHaELvx/mw22v2YqUf/3jedQImIJN0pSKycOKxT1RGddGzOdNajr6yJmp+vc6R7tYI2t7P+XxWRFHhaKPMjlWPYf09v/WqHJ6+OCrwS1cajwR4Y93zzkOWr2msy96uMx17q5IR8qbRSVTQPbIiUxjOlB2Q8W+TaBfaSkgzLrQjhuAK1ZN7Dygh3Ewkxl+pmRQU9EmqBaIOusMqVgWrEvAw7ccS2yW2uMOL2CXzBuD2qo/Ndvh5V4ZQR4/wZxBMr3yvrBzPZH9qYHfpO58v63oZKbREA3tnyR/qlJ7eRWUmG5pems4UmT+jjlAmPQwep9nL9B1QZHKzeQxIxIbqToqgtLvt+4NiAUk2KiYMqno+aliYK7Ju58f6spoAhALAU9rbGSeOVH7JUUUU52GcqIouRgaK7pg35PNx0NKnpAeFkYbEBHqyXgZSWoDKWP5bJr7DjOOYqYspKRaRS4ltY7TJtYwlTYO/DWdqGPRvAm6folzdTGtkgyi4MROWZtV73FAai3O46qRuYyYk7Y9kOOyfntKRZ/Y4bFYruVB1+J8C9GoK2DesV4UQzrkSkdn1XJgJ5CJbj7ikQI5e5X0Ij4c0TqmoGpwmJgavWq7oiVhJLVfJIqGoh7xekXdHqE288kUMGdIxIyaCU0goXfqwkYfK37vuy3GcyrIEQIUitf+iAqF2QruFt/ipCivl8fZ1hZH9URpzaQrrpdVyOoktW10CMVmRm180+/dmxqSxeBod8U67eh342hkZv6yKo5vLbAfHVaH23baFQ4HRXtViMqb5myM0V0NsubYZ5N+MD7tMlUf8NDfZJ4hV4FjwvrWn/z7FI5GPILXT0D80OfbOfpzqWQafmFkmmF3Sb69OnpXihYZgJ8pgjn4EeS97SAe0AFFpt8s5t3cepovlnMjZLr1fGpdRv66AFe4/G9AYuOd+owedfs5L1hVHxtS6xhUa8Tt8SFNvgJholwDqTOfJumRL3C85W9YCaJ8HgNE6xkWDIViCQ8Xr4RLpVQp3CYIvxxBAJpr0tYtLv7zVHx/zEsMTyMfndEqbRWxRVRZD268Kqhp6mEsmJeGxBIv59U9C/I23xGAmQ9HWEDDFdDvqYDS0Tr7G8ahR07UVrSVepwdL988CT5JJMGpUrfuyyf3lgWz6IZELIO3+Z3Zv59MY9NWYoKg1jkKzkZYOFWcfIjnEW244hLfGeDZrWzsBq/+pu31lFXqeWBVvNZfMPGh8m8Or11OYCEwcc8WA+wfuJk9N0NgdTPR31+jyaw31s//3Ii4zeIJMpB2s7yhyk6G+HlmQjMCq1n5LeC6c6Da3/4oH0g71DKr0neZ+T+CRDbwOtk8+EwyLL9UrN42fg6zIaY31e6lcF5jpe10mplGtwGUysfgoTsk7+2CKoHAmSnZm467GuHslHL5q73Na7KSNRYx5zWbOsX5W0trhO117tyt2vv9vAdhkbRXz6/NDqIq+6VtW4mTtQRC2CuXD0ObwGbrpxtD4VJ6GuB628Frju/dZDIBNA7OwqHGFLfE9F6tOuIzSgec4ic7kHx2uUR0InsFbCxDJ/H6ue+zuFW8k6ItBMbk+yGYVcYmvVDE2HBJTLUdlPPzKDnSlglNlHwyk05q3B075XYHeR0BKNTYZT2zUO4cJET16ej+/6lUzoTk4ffSdkk0xWALFm/f5t1pyiUKuRq1CltrE9SuUbWaJQ+Uh4Qq9HvSqq6NkrntU9F5WnQbEUqNQ21UFfakmp1N7PWqtSvDYKFk98cplqN3xXDc80BOCuydDe6SIldvtpLiqOsxREwlboRnWa293hbQi08shmt0rTJq0y0Mj2jWIVNH3UkNHtuHTTWqtPdrYvKXIb1D0ljvr82fzns/P1qfvLgTktPDj/M7OT7ZvJxrbDTlH8bYZQykCssdTgDt/rNP8tJyAUqOwqnV2To3vVGcHLSLhN3r7sXbEx46UFX1Cvzekf9Ut/LIa/NbWQWM6JolxfbuACGKV9xU7Rbk0/sa5Sw+ytON/bBlQVMP9q1wpupYJyZsMqupVzbbTiSnK3GQG2foiKZCxJ7NgUMr0LgXR4kI9u3FuKJ4otS+DcyHCSkEzyf4bXKgbtgM6TX0Iss6ByKsMKn+IuidF179m2SDfOpOFGy+ZXnJxhVYwCPVAsg4UUaHM2zke1Kuy7NeTfxoChV4fItkd4ZV5NByXDGLcbLmvdxVvdW2D0RWwiktdR4XXmyfXpEebaAekQFlaq69qvQJpJBPkYrIbUpoD5Asxsnixa7Dp4WtTm9zoplPDs6OTx+//rorAmkFpX8EWuAoUEf35ag/49op7Sq69dxg5Vr6h0duI19a6jEev7VtXiWkg7VwSKZFu4HfnUwdRfZr4jN4MqFVkemZshCV28oKGPG8SAdYHyjVs0NiwCMfDJD7XOQj1bVGo/KyuixWSfO+F80y2MwcKrQAx0t9FScgsBn0huBzxWH2GmpMzyyus6wUbPy0OJKwoR5HVgxTzVghSxbGmP92JSLdwm6tklkC5qUUgKNe6MBjrh2Yggb3Top2LW3TvWtME7WTEXzhVPRDPmhA7wBfRgMAN5gQDLRQMhafIZs/V/aARma'
VPSCTL_SHA256='8d255aedc4370887806dee7048babc2448f041cee50d165f9e62be2265049e6d'

say() { printf '[RGNODES-NODE] %s\n' "$*"; }
die() { printf '[RGNODES-NODE] ERROR: %s\n' "$*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || die 'Run as root: sudo bash node.sh --api-key=KEY --port=PORT'
command -v python3 >/dev/null 2>&1 || die 'Python 3 is required.'
python3 - <<'PYVER' || die 'Python 3.10 or newer is required.'
import sys
raise SystemExit(0 if sys.version_info >= (3,10) else 1)
PYVER

API_KEY=''
PORT='18443'
HOST=''
KEY_SUPPLIED=0
KEY_GENERATED=0
FORCE_PROMPT_KEY=0
while (($#)); do
  case "$1" in
    --api-key|--api_key) (($# >= 2)) || die "$1 requires a value"; API_KEY="$2"; KEY_SUPPLIED=1; shift 2;;
    --api-key=*) API_KEY="${1#*=}"; KEY_SUPPLIED=1; shift;;
    --api_key=*) API_KEY="${1#*=}"; KEY_SUPPLIED=1; shift;;
    --prompt-api-key) FORCE_PROMPT_KEY=1; shift;;
    --port) (($# >= 2)) || die '--port requires a value'; PORT="$2"; shift 2;;
    --port=*) PORT="${1#*=}"; shift;;
    --host) (($# >= 2)) || die '--host requires a value'; HOST="$2"; shift 2;;
    --host=*) HOST="${1#*=}"; shift;;
    -h|--help) printf 'Usage: sudo bash node.sh [--api-key KEY] [--prompt-api-key] [--port 18443] [--host 127.0.0.1]\n'; exit 0;;
    *) die "Unknown option: $1";;
  esac
done
[[ "$PORT" =~ ^[0-9]+$ ]] && ((PORT >= 1 && PORT <= 65535)) || die 'Port must be an integer from 1 to 65535.'

export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a APT_LISTCHANGES_FRONTEND=none
command -v apt-get >/dev/null 2>&1 || die 'Debian/Ubuntu apt-get is required.'
say 'Installing KVM/QEMU/libvirt and node-agent runtime packages.'
apt-get update
apt-get install -y sudo net-tools cpu-checker python3 ca-certificates curl iproute2 iputils-ping openssl \
  qemu-system-x86 qemu-utils libvirt-daemon-system libvirt-clients \
  cloud-image-utils openssh-server openssh-client sshpass acl ufw
for unit in libvirtd.service virtqemud.service virtlogd.service virtlockd.service; do
  systemctl enable --now "$unit" >/dev/null 2>&1 || true
done
command -v virsh >/dev/null 2>&1 || die 'virsh is unavailable after package installation.'
command -v qemu-img >/dev/null 2>&1 || die 'qemu-img is unavailable after package installation.'
[[ -e /dev/kvm ]] || die '/dev/kvm is missing. Enable hardware/nested virtualization at your VPS provider before using this node.'
virsh -c qemu:///system list --all >/dev/null 2>&1 || die 'libvirt qemu:///system did not become ready; inspect libvirtd/virtqemud.'

APP=/opt/rgnodes-node-agent
ENV_DIR=/etc/rgnodes
ENV_FILE="$ENV_DIR/node-agent.env"
CONTROLLER=/usr/local/sbin/vpsctl
UNIT=/etc/systemd/system/rgnodes-node-agent.service
install -d -m 0755 "$APP" "$ENV_DIR" /var/lib/rgnodes-vps/images /var/lib/rgnodes-vps/disks /var/lib/rgnodes-vps/seeds /var/lib/rgnodes-vps/meta /var/lib/rgnodes-vps/secrets
chmod 0700 /var/lib/rgnodes-vps /var/lib/rgnodes-vps/secrets

if (( FORCE_PROMPT_KEY )) && [[ ! -t 0 ]]; then
  die '--prompt-api-key requires an interactive terminal so the new secret can be entered without being echoed.'
fi
if (( FORCE_PROMPT_KEY )); then
  API_KEY=''
elif [[ -z "$API_KEY" ]]; then
  API_KEY="$(python3 - "$ENV_FILE" <<'PYKEY'
import sys
from pathlib import Path
p=Path(sys.argv[1])
if p.exists():
    for line in p.read_text(encoding='utf-8',errors='replace').splitlines():
        s=line.strip()
        if s and not s.startswith('#') and '=' in s:
            k,v=s.split('=',1)
            if k.strip()=='RGNODES_NODE_API_KEY':
                v=v.strip().strip('"').strip("'")
                if len(v)>=32: print(v); raise SystemExit(0)
print('')
PYKEY
)"
fi
if [[ -z "$API_KEY" && -t 0 ]]; then
  read -r -s -p 'Enter the node API key from the bot DM (input hidden): ' API_KEY
  printf '\n'
  [[ -z "$API_KEY" ]] || KEY_SUPPLIED=1
fi
if [[ -z "$API_KEY" ]]; then
  API_KEY="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  KEY_GENERATED=1
fi
[[ ${#API_KEY} -ge 32 && "$API_KEY" != *[$'\r\n '$'\t']* ]] || die 'API key must be at least 32 non-whitespace characters.'

if [[ -z "$HOST" ]]; then
  HOST="$(python3 - "$ENV_FILE" <<'PYHOST'
import sys
from pathlib import Path
p=Path(sys.argv[1])
if p.exists():
    for line in p.read_text(encoding='utf-8',errors='replace').splitlines():
        s=line.strip()
        if s and not s.startswith('#') and '=' in s:
            k,v=s.split('=',1)
            if k.strip()=='RGNODES_AGENT_HOST': print(v.strip().strip('"').strip("'")); raise SystemExit(0)
print('127.0.0.1')
PYHOST
)"
fi
[[ "$HOST" =~ ^[A-Za-z0-9.:_-]+$ ]] || die 'Invalid bind host. Use 127.0.0.1, ::1, or an intentional interface address.'

# Decompress to private temporary files, check exact digests, then atomically install.
python3 - "$NODE_AGENT_ZLIB_B64" "$NODE_AGENT_SHA256" "$VPSCTL_ZLIB_B64" "$VPSCTL_SHA256" "$APP/node-agent.py" "$CONTROLLER" <<'PYEMBED'
import base64,hashlib,os,sys,tempfile,zlib
agent_b64,agent_hash,ctl_b64,ctl_hash,agent_out,ctl_out=sys.argv[1:]
for encoded,expected,target in ((agent_b64,agent_hash,agent_out),(ctl_b64,ctl_hash,ctl_out)):
    data=zlib.decompress(base64.b64decode(encoded,validate=True))
    if hashlib.sha256(data).hexdigest()!=expected:
        raise SystemExit(f'Embedded payload integrity check failed for {target}')
    if target.endswith('node-agent.py'):
        compile(data.decode('utf-8'),'node-agent.py','exec')
    else:
        text=data.decode('utf-8')
        compile(text,'vpsctl','exec')
        if not all(x in text for x in ('KVM/QEMU/libvirt only','def compat(','virsh')):
            raise SystemExit('Embedded controller is not the expected KVM controller')
    directory=os.path.dirname(target)
    fd,tmp=tempfile.mkstemp(prefix='.rgnodes-embed-',dir=directory)
    try:
        with os.fdopen(fd,'wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp,0o755); os.replace(tmp,target)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass
print('Embedded node-agent and KVM controller hashes/syntax verified.')
PYEMBED

# Detect the provider uplink where possible; public IPv4 routing still depends on provider setup.
UPLINK="$(ip -4 route show default 2>/dev/null | awk '/^default/ {for(i=1;i<=NF;i++) if($i=="dev") {print $(i+1); exit}}' || true)"

# Atomically write credentials and fill missing network defaults without replacing custom settings.
python3 - "$ENV_FILE" "$API_KEY" "$HOST" "$PORT" "$CONTROLLER" "$UPLINK" <<'PYENV'
import os,sys,tempfile
from pathlib import Path
path=Path(sys.argv[1]); api_key,host,port,controller,uplink=sys.argv[2:]
forced={
    'RGNODES_NODE_API_KEY':api_key,
    'RGNODES_AGENT_HOST':host,
    'RGNODES_AGENT_PORT':port,
    'RGNODES_VPSCTL_PATH':controller,
}
defaults={
    'RGNODES_VPS_ROOT':'/var/lib/rgnodes-vps',
    'KVM_NETWORK_MODE':'direct',
    'PUBLIC_PARENT_INTERFACE':uplink.strip(),
    'PUBLIC_BRIDGE_NAME':'',
    'REAL_PUBLIC_IPV4_REQUIRED':'true',
    'PUBLIC_IPV4_POOL_CIDR':'',
    'PUBLIC_IPV4_GATEWAY':'',
    'PUBLIC_IPV4_DNS':'1.1.1.1,8.8.8.8',
    'HOST_RAM_RESERVE_GB':'2',
    'HOST_CPU_RESERVE':'1',
    'HOST_VCPU_OVERCOMMIT_RATIO':'1.5',
    'HOST_DISK_RESERVE_GB':'10',
    'MAX_DEPLOY_RAM_SHARE':'0.80',
    'HOST_CPU_MAX_DEPLOY_PCT':'85',
    'MIN_HOST_RAM_FREE_PCT_DEPLOY':'18',
    'MAX_VPS_RAM_GB':'22',
    'MAX_VPS_CPU':'10',
    'MIN_VPS_DISK_GB':'10',
    'MAX_VPS_DISK_GB':'100',
    'INITIAL_VPS_RAM_GB':'8',
    'INITIAL_VPS_CPU':'2',
    'INITIAL_VPS_DISK_GB':'25',
    'DEFAULT_VPS_RAM_GB':'8',
    'DEFAULT_VPS_CPU':'2',
    'DEFAULT_VPS_STORAGE_GB':'25',
    'RESOURCE_AUTOSCALE_ENABLED':'false',
    'RESOURCE_AUTOSCALE_INTERVAL':'300',
}
existing=path.read_text(encoding='utf-8',errors='replace').splitlines() if path.exists() else []
out=[]; seen=set()
def unquote(value):
    value=value.strip()
    if len(value)>=2 and value[0]==value[-1] and value[0] in '"\'': value=value[1:-1]
    return value
for line in existing:
    item=line.strip()
    if item and not item.startswith('#') and '=' in item:
        key,value=item.split('=',1); key=key.strip()
        if key in forced or key in defaults:
            if key in seen: continue
            seen.add(key)
            if key in forced: value=forced[key]
            elif not unquote(value): value=defaults[key]
            else: value=unquote(value)
            out.append(f'{key}={value}')
            continue
    out.append(line)
for mapping in (forced,defaults):
    for key,value in mapping.items():
        if key not in seen: out.append(f'{key}={value}'); seen.add(key)
fd,tmp=tempfile.mkstemp(prefix='.node-agent-env-',dir=str(path.parent))
try:
    with os.fdopen(fd,'w',encoding='utf-8') as f: f.write('\n'.join(out)+'\n'); f.flush(); os.fsync(f.fileno())
    os.chmod(tmp,0o600); os.replace(tmp,path)
finally:
    try: os.unlink(tmp)
    except FileNotFoundError: pass
PYENV

# Upgrade only known legacy defaults on an existing node; retain explicit custom settings.
python3 - "$ENV_FILE" <<'PYMIGRATE'
import os,sys,tempfile
from pathlib import Path
p=Path(sys.argv[1]); lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
changes={
 'MAX_VPS_RAM_GB':('8','22'), 'MAX_VPS_CPU':('8','10'),
 'INITIAL_VPS_RAM_GB':('1','8'), 'INITIAL_VPS_CPU':('1','2'),
 'INITIAL_VPS_DISK_GB':('10','25'), 'DEFAULT_VPS_RAM_GB':('1','8'),
 'RESOURCE_AUTOSCALE_ENABLED':('true','false'), 'RESOURCE_AUTOSCALE_INTERVAL':('30','300'),
}
out=[]; seen=set(); migrated=[]
for line in lines:
 s=line.strip()
 if s and not s.startswith('#') and '=' in s:
  key,value=s.split('=',1); key=key.strip(); value=value.strip().strip('"').strip("'")
  if key in changes and key not in seen:
   seen.add(key); old,new=changes[key]
   if value.lower()==old.lower(): value=new; migrated.append(key)
   out.append(f'{key}={value}'); continue
 out.append(line)
fd,tmp=tempfile.mkstemp(prefix='.node-agent-policy-',dir=str(p.parent))
try:
 with os.fdopen(fd,'w',encoding='utf-8') as f: f.write('\n'.join(out)+'\n'); f.flush(); os.fsync(f.fileno())
 os.chmod(tmp,0o600); os.replace(tmp,p)
finally:
 try: os.unlink(tmp)
 except FileNotFoundError: pass
if migrated: print('Migrated legacy node defaults: '+', '.join(migrated))
PYMIGRATE

cat > "$UNIT" <<EOF
[Unit]
Description=RGNODES Remote KVM VPS Node Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=$APP
EnvironmentFile=$ENV_FILE
Environment=PYTHONUNBUFFERED=1
ExecStart=/usr/bin/python3 $APP/node-agent.py
Restart=on-failure
RestartSec=3
StartLimitIntervalSec=300
StartLimitBurst=5
LimitNOFILE=65535
UMask=0077

[Install]
WantedBy=multi-user.target
EOF
chmod 0644 "$UNIT"
python3 -m py_compile "$APP/node-agent.py" "$CONTROLLER"
systemctl daemon-reload
systemctl enable --now rgnodes-node-agent.service
systemctl is-active --quiet rgnodes-node-agent.service || { journalctl -u rgnodes-node-agent.service -n 60 --no-pager || true; die 'node-agent service did not start'; }

# Do not auto-open firewall ports or bind publicly; plain HTTP is not safe on an exposed interface.
if [[ "$HOST" != '127.0.0.1' && "$HOST" != '::1' ]]; then
  say 'WARNING: the agent is bound to a non-loopback address. Restrict firewall access to a trusted VPN/TLS proxy; never expose plain HTTP to the Internet.'
fi
if (( KEY_GENERATED == 1 )); then
  printf '\nGenerated node API key (save it securely and enter the same key in the bot node settings):\n%s\n' "$API_KEY"
else
  say 'Node API key configured; secret is stored in /etc/rgnodes/node-agent.env with mode 0600.'
fi
say 'Remote KVM node agent is active. This host must have provider-routed public IPv4 if guests need direct public IPv4 addresses.'
