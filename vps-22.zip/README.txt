RGNODES™ VPS Deploying Bot V9 Manager Pro
========================================
Release: 9.3.1 — Automatic Local Node & Combined Local/Remote Operation

PACKAGE AND SECRETS
-------------------
The archive contains the bot, interactive installer, `.env` template, regression checker, remote node installer, one-command display-name editor, terminal proxy, checksums, and this guide. Secret-bearing .env values (Discord token, admin ID, node keys) are blank in the release. Never upload your configured .env or web_terminal.token to a public channel.

INSTALL
-------
1. Extract the ZIP on a supported Debian/Ubuntu Linux control host. Local + Remote node routing is always enabled. Installing KVM/QEMU/libvirt on the control host is optional; when local KVM is unavailable, configured remote nodes remain eligible. If `unzip` is missing, install it first with `sudo apt-get update && sudo apt-get install -y unzip`.
2. Keep `.env` private: `chmod 600 .env`. On first install, `setup.sh` opens an interactive wizard and asks for the Discord token (hidden), main/additional admin IDs, default RAM/CPU/disk, command prefix, Pinggy, IPv4 detection, and optional host tools.
3. Install/repair the host and bot using: `sudo bash setup.sh`. Do not pass `--check` for installation: check mode is read-only and exits after tests.
4. Read-only bundle validation: `sudo bash setup.sh --check`
5. Static validation: `bash check.sh --static`; host readiness report: `sudo bash check.sh --host`
6. To show the setup questions again on an existing install: `sudo env RGNODES_SETUP_WIZARD=1 bash setup.sh`. To explicitly approve a host-wide full upgrade, run `sudo env RGNODES_FULL_UPGRADE=1 bash setup.sh` only when you accept the reboot/service-restart risk.

A KVM/QEMU/libvirt stack and /dev/kvm are required only if this control host will run local guest VMs. They are not required for the bot to register a Local Node record or manage registered remote nodes. Network routing and public IPv4 still depend on the node/provider; a release archive cannot allocate public IPv4 addresses. Do not use documentation/test IP ranges in production.

HARDENED SETUP.SH — RELEASE 9.3.1
--------------------------------
The installer now prints a six-phase progress sequence for OS detection, dependency repair, optional host tools, source/venv preparation, systemd/regression validation, and 24/7 startup. The regression checker uses cached UTF-8 byte-offset source slices rather than repeatedly invoking the expensive standard-library AST source extractor; its static suite completed in about three seconds in the build environment. It performs a fail-fast, read-only regression check before changing host services. It serializes install/repair runs with a lock, verifies the embedded controller and remote-node agent digests, checks supported OS/Python versions and disk headroom, and validates path/service-name settings before writing privileged files. It never runs `.env` as shell code.

- `.env`, code, the systemd unit and the KVM controller receive protected snapshots. On a detected failure, the installer attempts to restore prior code/config/unit/controller state and the service's active/enabled state. Database backup uses SQLite's online backup API; live VM disks, metadata and VPS data are not replaced. This is best-effort rollback, not a transaction across OS package installation or an unavailable host.
- The installer rejects `.env` symlinks and unsafe pre-existing `.venv` ownership/permissions, keeps `.env` at mode 0600, verifies the generated systemd unit with `systemd-analyze verify`, and uses atomic file replacement for the unit/controller.
- The control-host bot process is bounded by systemd: default CPU quota 100% (about one logical CPU), `MemoryHigh` at 80% of the configured memory cap, `MemoryMax=1024M`, `TasksMax=512`, and low scheduling/IO weights. These are control-bot limits, separate from VPS guest RAM/CPU/disk plans. They are configurable in `.env` within guarded ranges; increasing them should be based on measured capacity.
- Dependency installation uses retries and only repairs/names required packages by default. The wizard offers `apt-get full-upgrade` explicitly because a full OS upgrade may restart services, replace kernels/hypervisor packages or require a reboot; this operation is not rollbackable. Non-interactive setup skips full-upgrade unless `sudo env RGNODES_FULL_UPGRADE=1 bash setup.sh` is explicitly supplied.
- On a fresh interactive install, optional prompts can install and enable host Docker Engine, install LXC tools, and install `neofetch` (or `fastfetch` if `neofetch` is absent). These optional prompts default to **No** unless the matching `.env` option is already enabled; answer `y` to opt in. Host Docker is separate from Docker-in-guest; LXC is an optional tool and does not change the managed KVM/QEMU backend. This avoids unrequested host package changes and keeps the control VPS lean.
- The wizard validates `MAIN_ADMIN_ID` and comma-separated `ADMIN_USER_IDS` as 15-22 digit Discord IDs, constrains default resource selections to configured ceilings, retains the existing command prefix on Enter, allows explicit Pinggy / public-IPv4 choices, and asks whether optional local KVM/QEMU/libvirt packages should be installed. Remote-only mode is not exposed or supported. A bot is not started until both its token and main admin ID are valid.
- The 24/7 process is a systemd service, enabled at boot and restarted after unexpected exits/failures (manual `systemctl stop` remains respected). The installer verifies the generated unit and confirms both enabled and active state. After `--static` checks finish, a separate progress line confirms the installer is continuing; only `setup.sh --check` exits in read-only mode.
- Setup output uses colored RGNODES status text only in an interactive terminal; `NO_COLOR` disables color, and logs/CI remain plain text.
- Runtime config consistency is enforced in `bot.py` too: CPU and disk defaults are clamped to canonical hard ceilings even when `.env` is edited without the wizard. The browser-terminal bind task is tracked so reconnecting Discord gateway events cannot race into duplicate port binds.
- `.env` now documents all frequently tuned runtime knobs (background repair concurrency, guest access retry interval, tunnel start timeout, audit snapshot lines, storage pool and backup directory); token/admin/terminal token values stay blank in the release template.

Recommended safe preflight:
  sudo bash setup.sh --check
  sudo bash check.sh --host

The first command is read-only and runs the bundle's static/regression suite using cached source slices (no repeated `ast.get_source_segment` scans). A `KeyboardInterrupt` traceback means the check was manually interrupted; it is not by itself evidence of a bot runtime exception. The second checks host readiness and does not replace real production validation. Installation may still require manual repair if the host loses power, the filesystem fails, dependencies cannot be downloaded, or a provider service is unavailable.


LOCAL + REMOTE NODE MODE (RELEASE 9.3.1)
---------------------------------------
Local + Remote routing is fixed on; `.env` and the setup wizard do not offer a remote-only mode. `setup.sh` asks whether to install KVM/QEMU/libvirt on this control host; the safe default is **No** to keep the main VPS lean. On bot startup, `init_db()` automatically creates the `Local Node` database record if missing and best-effort detects its city/region/country from the control host public egress IP (with a timezone fallback). The external geo lookup runs only when the Local Node has no meaningful saved location and uses a short timeout; this sends the host egress IP to the configured geo provider. `LOCAL_KVM_ENABLED=false` means the installer will not install/start host KVM services, but a previously working local KVM stack remains eligible. If local KVM is unavailable, new deployments select a registered remote node; if none exists, the bot returns a clear readiness error rather than pretending the Local Node is ready. Register remote nodes with `-node create`. `DEFAULT_NODE_ID=0` prefers Local Node only when KVM/libvirt is ready; an explicit remote ID pins the preferred remote node. A local node can deploy real VMs only when the provider exposes `/dev/kvm`, libvirt is ready, and there is sufficient host/network/storage capacity.


BRANDING, FIXED DEVELOPER IDENTITY & HOSTNAME
--------------------------------------------
The developer identity is hard-coded in `bot.py` as `𝐌ɾ. 𝐙ᥱ𝚝ɾ𝐢𝐱`; `BOT_DEVELOPER` is removed from `.env` and installer migrations remove any legacy override. The guest hostname base is fixed as `rgnodes-vps`; `VPS_HOSTNAME` is also removed from `.env`. The installer never calls `hostnamectl set-hostname` and does not change the main control host hostname. `BOT_NAME` changes only the bot's displayed label, not the Discord application's actual account username.

Change the displayed bot label in one command:
  sudo bash rename-bot.sh "RGNODES™ Edge"

This validates the label, backs up `.env`, writes it atomically and restarts the default `bot.service` if installed. If your systemd service uses a different name, set `RGNODES_SERVICE_NAME` for the command.

DEPLOY PROGRESS AND RESOURCE DISPLAY
------------------------------------
The deployment card uses the 15 RGNODES stages below, a moving activity bar and a completion bar. Each stage advances after its associated operation returns; external tunnel readiness is not falsely shown as online merely because a background bootstrap was queued.

1. Receiving VPS ID
2. Checking KVM / QEMU
3. Creating VPS Container
4. Applying Resource
5. Configure Package
6. 🐳 Docker Ready
7. Booting VPS
8. Fixing systemctl
9. Register In Bot Database
10. Installing SSH + Password
11. Making Public Real IPv4
12. Creating SSH
13. Creating PINGGY
14. Final Full Check and Repair
15. Finished

The deployment resource field shows RAM, CPU and disk only. Pinggy setup is asynchronous to prevent a slow provider from holding up the main VPS creation flow; its health state is confirmed separately by the repair/check worker. SSHX has been removed from active features. Older guests are checked by the existing low-frequency baseline repair task, which removes legacy SSHX artifacts only if they are found.

STATUS COMMANDS
---------------
The current bot command architecture is prefix-based. With the default prefix '-':
  -kvm-status [node_id]             Admin-only KVM/QEMU/libvirt health
  -ssh-status <VPS ID or name>      VPS owner/admin SSH service status
  -docker-status <VPS ID or name>   VPS owner/admin Docker status

Replace '-' if PREFIX in .env has changed. Status commands do not reveal root passwords or node API keys.

RGNODES™ OPENSSH TERMINAL (PUBLIC HTTPS DOMAIN)
------------------------------------------------
Public terminal URL: https://ssh.rgnodes.bond
Local backend: http://127.0.0.1:909 (loopback only; do not expose port 909 publicly)

The bot serves the browser terminal only on 127.0.0.1. For the HTTPS domain to work, these server-side requirements must all be satisfied:
- DNS A/AAAA records for ssh.rgnodes.bond point only to the real host that will serve this terminal. Remove an incorrect AAAA record if IPv6 is not actually routed.
- Public TCP ports 80 and 443 reach the Nginx host.
- A valid certificate and key exist at /etc/letsencrypt/live/ssh.rgnodes.bond/fullchain.pem and privkey.pem.
- The included nginx-ssh-terminal.conf is installed and enabled; it rate-limits logins, forwards WebSockets and overwrites X-Forwarded-For with Nginx's actual client address.

Obtain a certificate first. If an existing Nginx site is already serving the domain, the common option is:
  sudo certbot certonly --nginx -d ssh.rgnodes.bond

Use standalone mode only if port 80 is free (stop any service already listening on port 80 first):
  sudo certbot certonly --standalone -d ssh.rgnodes.bond

Then install the reference config and reload Nginx:
  sudo install -m 0644 nginx-ssh-terminal.conf /etc/nginx/conf.d/rgnodes-ssh-terminal.conf
  sudo nginx -t && sudo systemctl reload nginx

Confirm the bot is running with WEB_TERMINAL_ENABLED=true and WEB_TERMINAL_PORT=909 in .env, and allow dependencies from requirements.txt to install. Then open https://ssh.rgnodes.bond. The DNS, certificate, firewall and Nginx proxy are on your server/provider; they cannot be activated from the ZIP itself.

FIRST LOGIN TOKEN
-----------------
The first successful bot startup creates a random token at:
  /var/lib/rgnodes-vps/data/web_terminal.token

Read it locally from a trusted server shell (the file is mode 0600):
  sudo cat /var/lib/rgnodes-vps/data/web_terminal.token

If RGNODES_DATA_DIR is configured, look for web_terminal.token under that configured data directory instead. You can set WEB_TERMINAL_TOKEN manually in .env, but use at least 32 random characters and keep it secret. The terminal uses token authentication, constant-time token comparison, a login rate limit, short-lived HttpOnly/SameSite cookies, a session cap and an SSH process cap.

LOCAL ACCESS / MOBILE ACCESS
----------------------------
On the server itself, open:
  http://localhost:0909

For a PC or phone without using the public domain, create an SSH local port-forward from that device:
  ssh -L 909:127.0.0.1:909 root@YOUR_SERVER_IP

Then open http://localhost:0909 on that same device and enter the private token. The basic responsive console supports interactive shell input, password prompts and common control keys; it is not a full xterm.js emulator for every full-screen terminal application. Only connect to systems you own or are authorized to administer.

RESOURCE / LOAD POLICY
----------------------
The browser SSH terminal is configured for up to 3 concurrent SSH processes by default. It has no high-frequency monitoring loop; guest baseline repair continues at its existing 18-hour interval. Deployment uses actual operation results for status and keeps Pinggy startup asynchronous. To avoid overload, keep RAM/CPU/disk admission limits enabled and do not raise session/resource caps without checking your real host capacity.

VERIFICATION AND TEST LIMITS
----------------------------
Run `bash check.sh --static` after installation for syntax, source integrity, command-alias, network guard, and embedded controller checks. The development sandbox regression suite covers embedded KVM controller allocation/rollback/health logic and static checks. This environment cannot prove a live Discord login, real /dev/kvm VM boot, provider-assigned public IPv4 route, external Pinggy readiness, production HTTPS certificate or DNS resolution. Those need a verification run on your configured production host. No software package can honestly guarantee zero errors on every OS/provider; test a first VPS before bulk deployment.


## Updated resource defaults and housekeeping

- Standard `-deploy`: default plan is 8 GiB RAM, 2 CPU cores, 25 GiB disk.
- Admin `-create <RAM> <CPU> <DISK> @user VPS`: up to 22 GiB RAM, 10 CPU cores, 100 GiB disk.
- Actual allocations are still subject to per-node RAM/CPU/disk reservations and live host-capacity preflight. The bot rejects or fits requests when the configured node cannot safely provide them; these ceilings are not a promise of physical capacity.
- Adaptive resource auto-scaling is disabled by default and, if explicitly enabled, checks at no less than five-minute intervals.
- Every five minutes the bot performs low-impact process-cache expiry, orphaned app-temp-file cleanup (only stale RGNODES atomic-write files under the private data directory), opportunistic SQLite optimization/passive checkpointing, and young-generation garbage collection. It does **not** flush Linux page cache, clear all of `/tmp`, delete VPS disks, or delete backups.
- Discord custom emoji provisioning uses the authoritative guild emoji list and skips creation when that list cannot be fetched, preventing restart-time duplicate names.


IDENTITY / HOSTNAME / DISPLAY NAME
----------------------------------
The developer identity is fixed in bot.py to `𝐌ɾ. 𝐙ᥱ𝚝ɾ𝐢𝐱` and ignores `.env` overrides. The managed guest hostname base is fixed to `rgnodes-vps`; the installer never runs hostnamectl or changes the main control host hostname. `BOT_NAME` is the configurable display name used in embeds/panels. Change it in one command from the application folder: `sudo bash rename-bot.sh "RGNODES™ Edge"`. The helper validates the label, backs up `.env`, writes atomically, keeps mode 0600, and restarts the configured systemd service when present. It changes the RGNODES display label only, not the Discord account username; Discord account username changes must be performed in the Discord Developer Portal.

CHECKER PERFORMANCE FIX
-----------------------
The static checker parses bot.py once and uses cached UTF-8 byte offsets to inspect AST source spans instead of calling Python's `ast.get_source_segment()` repeatedly. On the release environment, `bash check.sh --static` completes in about 3 seconds. If a user presses Ctrl+C, that interrupts the check; it does not mean bot.py raised an application error.
