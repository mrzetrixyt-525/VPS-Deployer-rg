#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
umask 077

# RGNODES™ installer. Uses .env as data (never `source`s it) and preserves runtime state.
# local host hostname is never modified; guest hostname/developer identity are fixed in bot.py.
# Combined Local + Remote node selection is always enabled. Installing host KVM/QEMU is a separate optional choice.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SOURCE_DIR="$(cd -- "${RGNODES_SOURCE_DIR:-$SCRIPT_DIR}" && pwd -P)"
APP_DIR="${RGNODES_APP_DIR:-/root/Bot2}"
SERVICE_NAME="${RGNODES_SERVICE_NAME:-bot.service}"
MODE="${1:-install}"
BANNER_SHOWN=0
CODE_FILES=(bot.py setup.sh check.sh node.sh rename-bot.sh requirements.txt ecosystem.config.js nginx-ssh-terminal.conf)
BUNDLE_FILES=(.env bot.py requirements.txt setup.sh check.sh node.sh rename-bot.sh ecosystem.config.js nginx-ssh-terminal.conf)

# Color is enabled only for interactive terminals; logs stay clean for systemd/CI.
if [[ -t 1 && -z "${NO_COLOR:-}" ]]; then
  RED=$'\033[0;31m'; GRN=$'\033[0;32m'; YEL=$'\033[1;33m'
  BLU=$'\033[0;34m'; MAG=$'\033[0;35m'; CYN=$'\033[0;36m'
  WHT=$'\033[1;37m'; DIM=$'\033[2m'; NC=$'\033[0m'
else
  RED=''; GRN=''; YEL=''; BLU=''; MAG=''; CYN=''; WHT=''; DIM=''; NC=''
fi

log(){ printf '%b[RGNODES™]%b %s\n' "$CYN" "$NC" "$*"; }
step(){ printf '%b[+]%b %s\n' "$GRN" "$NC" "$*"; }
warn(){ printf '%b[!]%b %s\n' "$YEL" "$NC" "$*" >&2; }
die(){ printf '%b[x]%b %s\n' "$RED" "$NC" "$*" >&2; exit 1; }

rainbow_line(){
  local text="$1" i color
  local -a colors=("$RED" "$YEL" "$GRN" "$CYN" "$BLU" "$MAG")
  if [[ -z "$NC" ]]; then printf '%s\n' "$text"; return; fi
  for ((i=0; i<${#text}; i++)); do
    color="${colors[$((i % ${#colors[@]}))]}"
    printf '%b%s%b' "$color" "${text:i:1}" "$NC"
  done
  printf '\n'
}

banner(){
  BANNER_SHOWN=1
  if [[ -t 1 && -n "${TERM:-}" && "$TERM" != dumb ]] && command -v clear >/dev/null 2>&1; then clear || true; fi
  printf '\n%b╔══════════════════════════════════════════════════════════════╗%b\n' "$CYN" "$NC"
  printf '%b║                                                              ║%b\n' "$CYN" "$NC"
  rainbow_line '                    >>> RGNODES™ <<<'
  printf '%b║                 VPS CONTROL PLATFORM                        ║%b\n' "$CYN" "$NC"
  printf '%b║                   Power By RGNODES™                         ║%b\n' "$CYN" "$NC"
  printf '%b║                                                              ║%b\n' "$CYN" "$NC"
  printf '%b╚══════════════════════════════════════════════════════════════╝%b\n' "$CYN" "$NC"
  printf '%b  KVM/QEMU • libvirt • Public IPv4 • SSH • Pinggy • Web Terminal%b\n' "$BLU" "$NC"
  printf '%b  Docker-in-guest • Auto MOTD • Discord dashboard • systemd%b\n' "$BLU" "$NC"
  printf '%b  Ubuntu/Debian auto-detect • Python venv • protected rollback%b\n\n' "$BLU" "$NC"
}

usage(){
  cat <<'USAGE'
Usage: sudo bash setup.sh [install|--code-only|--repair-controller|--check|--help]
  install      Install host dependencies, deploy/update the bot, and configure systemd.
  --code-only  Skip apt package installation; all host prerequisites must already exist.
  --repair-controller  Re-extract, hash-verify and atomically repair /usr/local/sbin/vpsctl only.
  --check      Run the bundle's static validation and regression tests without host changes.
  --help       Show this help.
Environment flags:
  RGNODES_SETUP_WIZARD=1  Re-open the interactive configuration wizard during an update.
  RGNODES_FULL_UPGRADE=1  Explicitly approve apt-get full-upgrade (may restart services/reboot).
Read-only check mode never installs packages or starts services.
USAGE
}

# No mode menu: `sudo bash setup.sh` automatically detects supported Debian/Ubuntu and runs full install.
if [[ $# -gt 1 ]]; then usage >&2; die 'Use at most one mode argument.'; fi
if [[ $# -eq 1 && "$MODE" == "--help" ]]; then banner; usage; exit 0; fi

if [[ "$MODE" == "--check" ]]; then
  [[ -s "$SOURCE_DIR/check.sh" ]] || die 'check.sh is missing.'
  exec bash "$SOURCE_DIR/check.sh" --static
fi
[[ "$MODE" == "install" || "$MODE" == "--code-only" || "$MODE" == "--repair-controller" ]] || { usage >&2; die "Unknown mode: $MODE"; }
if (( BANNER_SHOWN == 0 )); then banner; fi
[[ $EUID -eq 0 ]] || die 'Run as root: sudo bash setup.sh'
command -v flock >/dev/null 2>&1 || die 'flock is required to prevent concurrent setup/repair runs (install util-linux).'
install -d -m 0755 /run/lock
exec 9>/run/lock/rgnodes-vps-setup.lock
flock -n 9 || die 'Another RGNODES setup/repair process is running. Wait for it to finish before retrying.'
if [[ "$MODE" != "--repair-controller" ]]; then
  command -v systemctl >/dev/null 2>&1 || die 'systemd/systemctl is required. Generic CodeSandbox/container shells are not suitable for the KVM host installer.'
fi
if [[ "$MODE" == "install" ]]; then
  command -v apt-get >/dev/null 2>&1 || die 'apt-get is required; use --code-only only when system prerequisites are already installed.'
  [[ -r /etc/os-release ]] || die 'Cannot identify the operating system from /etc/os-release.'
  . /etc/os-release
  case "${ID:-}" in debian|ubuntu) ;; *) die "Supported OS is Debian/Ubuntu; detected ${PRETTY_NAME:-unknown}.";; esac
  log "Detected OS: ${PRETTY_NAME:-${ID:-unknown}}. Target backend: KVM/QEMU/libvirt."
fi
command -v python3 >/dev/null 2>&1 || die 'Python 3 is required.'
python3 - <<'PYVER' || die 'Python 3.10 or newer is required. Use Ubuntu 22.04+ or Debian 12+ (or install a supported Python first).'
import sys
raise SystemExit(0 if sys.version_info >= (3, 10) else 1)
PYVER

# Parse .env as data, never as shell code. Existing APP_DIR config wins over the bundled template.
CONFIG_ENV_FILE="$APP_DIR/.env"
if [[ ! -s "$CONFIG_ENV_FILE" ]]; then CONFIG_ENV_FILE="$SOURCE_DIR/.env"; fi
config_get(){
  local key="$1" file="${2:-$CONFIG_ENV_FILE}"
  [[ -s "$file" ]] || return 0
  python3 - "$file" "$key" <<'PYENVGET'
import sys
from pathlib import Path
path, wanted = sys.argv[1:]
try:
    lines = Path(path).read_text(encoding='utf-8', errors='replace').splitlines()
except OSError:
    raise SystemExit(0)
for line in lines:
    text = line.strip()
    if not text or text.startswith('#'):
        continue
    if text.startswith('export '):
        text = text[7:].lstrip()
    if '=' not in text:
        continue
    key, value = text.split('=', 1)
    if key.strip() != wanted:
        continue
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\\\"'":
        value = value[1:-1]
    print(value)
    break
PYENVGET
}

ENV_STATE_ROOT="${RGNODES_VPS_ROOT:-$(config_get RGNODES_VPS_ROOT)}"
STATE_ROOT="${ENV_STATE_ROOT:-/var/lib/rgnodes-vps}"
ENV_DATA_DIR="${RGNODES_DATA_DIR:-$(config_get RGNODES_DATA_DIR)}"
DATA_DIR="${ENV_DATA_DIR:-$STATE_ROOT/data}"
BACKUP_ROOT="${RGNODES_BACKUP_ROOT:-/var/backups/rgnodes-vps}"
FAIL2BAN_JAIL_FILE="/etc/fail2ban/jail.d/99-rgnodes-sshd.local"

# Resolve existing parent symlinks and dot segments before checking paths. The installer only
# accepts predictable paths because they are written into systemd units and used by root tooling.
canonical_path(){ python3 - "$1" <<'PYCANON'
import sys
from pathlib import Path
print(Path(sys.argv[1]).expanduser().resolve(strict=False))
PYCANON
}
APP_DIR="$(canonical_path "$APP_DIR")"
# First-install detection enables the interactive wizard only when useful; upgrades stay unattended
# unless the operator explicitly requests it with RGNODES_SETUP_WIZARD=1.
INSTALL_ALREADY_PRESENT=0
if [[ -s "$APP_DIR/bot.py" || -e "/etc/systemd/system/$SERVICE_NAME" || -L "/etc/systemd/system/$SERVICE_NAME" ]]; then
  INSTALL_ALREADY_PRESENT=1
fi
WIZARD_ACTIVE=0
if [[ "$MODE" == "install" && -t 0 && -r /dev/tty ]]; then
  if (( INSTALL_ALREADY_PRESENT == 0 )) || [[ "${RGNODES_SETUP_WIZARD:-0}" == "1" ]]; then WIZARD_ACTIVE=1; fi
fi
STATE_ROOT="$(canonical_path "$STATE_ROOT")"
DATA_DIR="$(canonical_path "$DATA_DIR")"
BACKUP_ROOT="$(canonical_path "$BACKUP_ROOT")"
for named_path in "APP_DIR=$APP_DIR" "STATE_ROOT=$STATE_ROOT" "DATA_DIR=$DATA_DIR" "BACKUP_ROOT=$BACKUP_ROOT"; do
  path="${named_path#*=}"
  [[ "$path" =~ ^/[A-Za-z0-9._/-]+$ ]] || die "${named_path%%=*} contains unsupported characters; use an absolute path with letters, digits, dot, underscore, slash or hyphen only."
done
for path in "$APP_DIR" "$STATE_ROOT" "$DATA_DIR" "$BACKUP_ROOT"; do
  case "$path" in
    /|/etc|/usr|/usr/local|/var|/var/lib|/var/log|/var/backups|/root|/home|/tmp|/run|/boot|/proc|/sys|/dev|/opt|/srv|/mnt)
      die "Refusing broad/system directory as an application path: $path";;
  esac
done
path_overlap(){ [[ "$1" == "$2" || "$1" == "$2/"* || "$2" == "$1/"* ]]; }
path_overlap "$APP_DIR" "$STATE_ROOT" && die 'APP_DIR and STATE_ROOT must not overlap.'
path_overlap "$APP_DIR" "$BACKUP_ROOT" && die 'APP_DIR and BACKUP_ROOT must not overlap.'
path_overlap "$STATE_ROOT" "$BACKUP_ROOT" && die 'STATE_ROOT and BACKUP_ROOT must not overlap.'
path_overlap "$DATA_DIR" "$APP_DIR" && die 'DATA_DIR and APP_DIR must not overlap.'
path_overlap "$DATA_DIR" "$BACKUP_ROOT" && die 'DATA_DIR and BACKUP_ROOT must not overlap.'
if path_overlap "$DATA_DIR" "$STATE_ROOT" && [[ "$DATA_DIR" != "$STATE_ROOT/"* ]]; then
  die 'DATA_DIR may be inside STATE_ROOT, but it must not be STATE_ROOT itself or an ancestor of it.'
fi
[[ "$SERVICE_NAME" =~ ^[A-Za-z0-9_.@-]+\.service$ ]] || die 'RGNODES_SERVICE_NAME must be a simple systemd unit name ending in .service.'
for f in "${BUNDLE_FILES[@]}"; do
  [[ -f "$SOURCE_DIR/$f" && ! -L "$SOURCE_DIR/$f" && -s "$SOURCE_DIR/$f" ]] || die "Required bundle file is missing, empty or a symlink: $f"
done

# Catch nearly-full filesystems before apt/pip starts modifying the host. Under 350 MiB is a
# hard stop; under 1 GiB is a warning because the dependency footprint varies by OS image.
if [[ "$MODE" != "--repair-controller" ]] && command -v df >/dev/null 2>&1; then
  declare -A _checked_mounts=()
  for requested_path in "$APP_DIR" "$STATE_ROOT" "$DATA_DIR" "$BACKUP_ROOT"; do
    probe="$requested_path"
    while [[ ! -e "$probe" && "$probe" != / ]]; do probe="$(dirname -- "$probe")"; done
    mount_key="$(df -Pk "$probe" 2>/dev/null | awk 'NR==2 {print $1 ":" $4}')"
    [[ -n "$mount_key" ]] || continue
    [[ -n "${_checked_mounts[$mount_key]:-}" ]] && continue
    _checked_mounts[$mount_key]=1
    free_kib="${mount_key##*:}"
    if [[ "$free_kib" =~ ^[0-9]+$ ]]; then
      (( free_kib >= 350000 )) || die "Less than 350 MiB free on the filesystem backing $probe; free space before installing to avoid a partial update."
      (( free_kib >= 1048576 )) || warn "Less than 1 GiB free on the filesystem backing $probe; apt/pip installation and backups may need additional space."
    fi
  done
fi

# Verify the compact bundle before any host mutation. Controller/agent source is embedded in
# bot.py and node.sh; it is not expected as a separate release file.
python3 - "$SOURCE_DIR/bot.py" "$SOURCE_DIR/node.sh" <<'PYVERIFY'
import ast,base64,hashlib,re,sys,zlib
from pathlib import Path
bot_path,node_path=map(Path,sys.argv[1:])
bot=bot_path.read_text(encoding='utf-8'); node=node_path.read_text(encoding='utf-8')
ast.parse(bot,filename='bot.py')
patterns={
 'controller':(r"_EMBEDDED_VPSCTL_ZLIB_B64\s*=\s*(['\"])(.*?)\1",r"_EMBEDDED_VPSCTL_SHA256\s*=\s*['\"]([0-9a-f]{64})['\"]",bot),
 'node agent':(r"^NODE_AGENT_ZLIB_B64='([^']+)'$",r"^NODE_AGENT_SHA256='([0-9a-f]{64})'$",node),
 'node controller':(r"^VPSCTL_ZLIB_B64='([^']+)'$",r"^VPSCTL_SHA256='([0-9a-f]{64})'$",node),
}
payloads={}
for name,(payload_re,hash_re,source) in patterns.items():
    flags=re.M|re.S if name=='controller' else re.M
    m=re.search(payload_re,source,flags); h=re.search(hash_re,source,flags)
    if not m or not h: raise SystemExit(f'{name}: embedded payload/hash missing')
    raw=zlib.decompress(base64.b64decode(m.group(2) if name=='controller' else m.group(1),validate=True))
    if hashlib.sha256(raw).hexdigest()!=h.group(1): raise SystemExit(f'{name}: embedded SHA-256 mismatch')
    ast.parse(raw.decode('utf-8'),filename=name)
    payloads[name]=raw
if payloads['controller'] != zlib.decompress(base64.b64decode(re.search(patterns['node controller'][0],node,re.M).group(1),validate=True)):
    raise SystemExit('bot.py and node.sh carry different KVM controllers')
if not all(s in payloads['controller'].decode() for s in ('KVM/QEMU/libvirt only','def compat(','virsh')):
    raise SystemExit('embedded controller markers mismatch')
if not all(s in payloads['node agent'].decode() for s in ('X-API-Key','def build_vpsctl_argv','ThreadingHTTPServer')):
    raise SystemExit('embedded node agent security/interface markers mismatch')
print('Bundle validation passed: bot.py, embedded KVM controller, node agent and hashes are consistent.')
PYVERIFY

# Run the release's host-independent regression suite before apt, environment migration or service
# changes. A malformed release must fail before it can replace a working deployment.
if [[ "$MODE" != "--repair-controller" ]]; then
  step 'Running read-only source and regression checks before any host changes...'
  bash "$SOURCE_DIR/check.sh" --static || die 'The source bundle failed static/regression checks; no application files or services were changed.'
  step 'Release checks passed; continuing with configuration, dependency repair and 24/7 service setup.'
fi

# Dedicated controller repair path. This is useful when an older install or a directory/symlink
# at /usr/local/sbin/vpsctl prevents the bot from finding the trusted KVM controller. It does not
# reinstall packages, replace .env, or touch VM disks/database.
if [[ "$MODE" == "--repair-controller" ]]; then
  REPAIR_TARGET=/usr/local/sbin/vpsctl
  REPAIR_DIR="$(dirname -- "$REPAIR_TARGET")"
  REPAIR_STAMP="$(date +%Y%m%d-%H%M%S)-$$"
  REPAIR_TMP="$REPAIR_DIR/.vpsctl.rgnodes-repair-$REPAIR_STAMP"
  REPAIR_BACKUP=''
  install -d -m 0755 "$REPAIR_DIR"
  cleanup_repair(){ [[ -z "$REPAIR_TMP" || ! -e "$REPAIR_TMP" ]] || rm -f -- "$REPAIR_TMP"; }
  trap cleanup_repair EXIT
  python3 - "$SOURCE_DIR/bot.py" "$REPAIR_TMP" <<'PYREPAIR'
import base64, hashlib, os, re, sys, zlib
from pathlib import Path
bot_path, out_path = map(Path, sys.argv[1:])
s = bot_path.read_text(encoding='utf-8')
p = re.search(r"_EMBEDDED_VPSCTL_ZLIB_B64\s*=\s*(['\"])(.*?)\1", s, re.S)
h = re.search(r"_EMBEDDED_VPSCTL_SHA256\s*=\s*['\"]([0-9a-f]{64})['\"]", s)
if not p or not h:
    raise SystemExit('Embedded controller payload/hash is missing from bot.py; use a matching complete release ZIP.')
try:
    payload = zlib.decompress(base64.b64decode(p.group(2), validate=True))
except Exception as e:
    raise SystemExit(f'Embedded controller payload is corrupt: {type(e).__name__}')
if hashlib.sha256(payload).hexdigest() != h.group(1):
    raise SystemExit('Embedded controller SHA-256 does not match the bot release.')
text = payload.decode('utf-8')
if not all(marker in text for marker in ('KVM/QEMU/libvirt only', 'def compat(', 'virsh')):
    raise SystemExit('Controller payload does not match the required KVM backend.')
compile(text, str(out_path), 'exec')
out_path.write_bytes(payload)
os.chmod(out_path, 0o755)
print('Extracted controller SHA-256:', hashlib.sha256(payload).hexdigest())
PYREPAIR
  chown root:root "$REPAIR_TMP"
  chmod 0755 "$REPAIR_TMP"
  if [[ -e "$REPAIR_TARGET" || -L "$REPAIR_TARGET" ]]; then
    REPAIR_BACKUP="${REPAIR_TARGET}.legacy-${REPAIR_STAMP}"
    if [[ -e "$REPAIR_BACKUP" || -L "$REPAIR_BACKUP" ]]; then die "Refusing to overwrite existing backup path: $REPAIR_BACKUP"; fi
    mv -T -- "$REPAIR_TARGET" "$REPAIR_BACKUP" || die "Could not preserve the existing controller path: $REPAIR_TARGET"
  fi
  if ! mv -T -- "$REPAIR_TMP" "$REPAIR_TARGET"; then
    if [[ -n "$REPAIR_BACKUP" && ( -e "$REPAIR_BACKUP" || -L "$REPAIR_BACKUP" ) ]]; then mv -T -- "$REPAIR_BACKUP" "$REPAIR_TARGET" || true; fi
    die 'Could not atomically install the KVM controller; old path was restored where possible.'
  fi
  REPAIR_TMP=''
  if ! python3 - "$SOURCE_DIR/bot.py" "$REPAIR_TARGET" <<'PYVERIFYCTL'
import hashlib, os, re, sys
from pathlib import Path
bot_path, ctl_path = map(Path, sys.argv[1:])
s = bot_path.read_text(encoding='utf-8')
h = re.search(r"_EMBEDDED_VPSCTL_SHA256\s*=\s*['\"]([0-9a-f]{64})['\"]", s)
data = ctl_path.read_bytes()
text = data.decode('utf-8', errors='replace')
if not h or hashlib.sha256(data).hexdigest() != h.group(1): raise SystemExit('Installed controller SHA-256 mismatch.')
if not all(x in text for x in ('KVM/QEMU/libvirt only', 'def compat(', 'virsh')): raise SystemExit('Installed controller markers mismatch.')
if not os.access(ctl_path, os.X_OK): raise SystemExit('Installed controller is not executable.')
compile(data.decode('utf-8'), str(ctl_path), 'exec')
print('Installed controller verified:', ctl_path, hashlib.sha256(data).hexdigest())
PYVERIFYCTL
  then
    rm -f -- "$REPAIR_TARGET"
    if [[ -n "$REPAIR_BACKUP" && ( -e "$REPAIR_BACKUP" || -L "$REPAIR_BACKUP" ) ]]; then mv -T -- "$REPAIR_BACKUP" "$REPAIR_TARGET" || true; fi
    die 'Post-install controller verification failed; previous path restored where possible.'
  fi
  log "Hash-verified KVM controller repaired at $REPAIR_TARGET."
  [[ -z "$REPAIR_BACKUP" ]] || log "Previous controller preserved at $REPAIR_BACKUP."
  log "Restart the bot with: systemctl restart $SERVICE_NAME"
  exit 0
fi

mkdir -p "$APP_DIR"
APP_DIR="$(cd -- "$APP_DIR" && pwd -P)"
chown root:root "$APP_DIR"
chmod 0750 "$APP_DIR"
if [[ -L "$APP_DIR/.venv" ]]; then die 'Refusing a symlink at APP_DIR/.venv; recreate the virtual environment as a real root-owned directory.'; fi
if [[ -d "$APP_DIR/.venv" ]]; then
  python3 - "$APP_DIR/.venv" <<'PYVENVGUARD' || die 'Existing .venv is not root-owned or is group/world-writable; secure/recreate it before running setup.'
import os,stat,sys
p=sys.argv[1]; st=os.lstat(p)
if not stat.S_ISDIR(st.st_mode) or st.st_uid != 0 or (st.st_mode & 0o022): raise SystemExit(1)
PYVENVGUARD
fi
ENV_FILE="$APP_DIR/.env"
STAMP="$(date +%Y%m%d-%H%M%S)"
install -d -m 0700 "$BACKUP_ROOT/source-snapshots" "$BACKUP_ROOT/db-snapshots" "$DATA_DIR"
chmod 0700 "$DATA_DIR"
BACKUP_DIR="$BACKUP_ROOT/source-snapshots/$STAMP"
install -d -m 0700 "$BACKUP_DIR"
STAGE_DIR="$(mktemp -d "$APP_DIR/.rgnodes-stage.XXXXXX")"
WAS_ACTIVE=0
WAS_ENABLED=0
ROLLBACK_ARMED=0
CONFIG_ROLLBACK_ARMED=0
ENV_ORIGINAL_PRESENT=0
CONTROLLER_ORIGINAL_TYPE='unknown'
UNIT_ORIGINAL_TYPE='unknown'
SYSTEMD_UNIT_PATH="/etc/systemd/system/$SERVICE_NAME"
LEGACY_CONTROLLER_PATH=''
CTL_TMP=''
UNIT_TMP=''
JAIL_TMP=''
if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then WAS_ACTIVE=1; fi
if systemctl is-enabled --quiet "$SERVICE_NAME" 2>/dev/null; then WAS_ENABLED=1; fi

restore_env_config(){
  if (( ENV_ORIGINAL_PRESENT == 1 )) && [[ -f "$BACKUP_DIR/.env-original" ]]; then
    local restore_tmp="$APP_DIR/.env.rollback.$$" backup_tmp=''
    if cp -p -- "$BACKUP_DIR/.env-original" "$restore_tmp" && mv -fT -- "$restore_tmp" "$ENV_FILE"; then
      chmod 0600 "$ENV_FILE" 2>/dev/null || true
      # Keep the private recovery copy aligned with the restored config after a failed update.
      if [[ -d "$DATA_DIR" ]]; then
        if backup_tmp="$(mktemp "$DATA_DIR/.env-backup-rollback.XXXXXX")"; then
          if install -m 0600 "$ENV_FILE" "$backup_tmp" && mv -fT -- "$backup_tmp" "$DATA_DIR/env.backup"; then
            backup_tmp=''
          else
            rm -f -- "$backup_tmp" 2>/dev/null || true
            warn 'The .env was restored, but the private env.backup copy could not be refreshed.'
          fi
        else
          warn 'The .env was restored, but a temporary path for env.backup could not be created.'
        fi
      fi
      log 'Restored the original .env after the failed setup; secret values were not printed.'
    else
      rm -f -- "$restore_tmp" 2>/dev/null || true
      warn "Could not restore the original .env automatically; protected snapshot remains at $BACKUP_DIR/.env-original."
    fi
  fi
}
restore_controller(){
  local target=/usr/local/sbin/vpsctl restore_tmp="/usr/local/sbin/.vpsctl.rollback-$$"
  if [[ -n "$LEGACY_CONTROLLER_PATH" && ( -e "$LEGACY_CONTROLLER_PATH" || -L "$LEGACY_CONTROLLER_PATH" ) ]]; then
    if [[ -e "$target" || -L "$target" ]]; then
      if [[ -d "$target" && ! -L "$target" ]]; then
        warn "Unexpected directory appeared at $target; preserved it and did not recursively delete it."
        return 1
      fi
      rm -f -- "$target" || { warn "Could not remove failed controller at $target."; return 1; }
    fi
    mv -T -- "$LEGACY_CONTROLLER_PATH" "$target" || { warn "Could not restore legacy controller object from $LEGACY_CONTROLLER_PATH."; return 1; }
    return 0
  fi
  case "$CONTROLLER_ORIGINAL_TYPE" in
    file|symlink)
      if [[ -d "$target" && ! -L "$target" ]]; then
        warn "Unexpected directory appeared at $target; previous controller snapshot is at $BACKUP_DIR/vpsctl-object."
        return 1
      fi
      rm -f -- "$restore_tmp" 2>/dev/null || true
      if cp -a -- "$BACKUP_DIR/vpsctl-object" "$restore_tmp" && mv -fT -- "$restore_tmp" "$target"; then return 0; fi
      rm -f -- "$restore_tmp" 2>/dev/null || true
      warn "Could not restore the prior controller object; snapshot is at $BACKUP_DIR/vpsctl-object."
      return 1
      ;;
    absent)
      if [[ -e "$target" || -L "$target" ]]; then
        if [[ -d "$target" && ! -L "$target" ]]; then
          warn "Unexpected directory appeared at $target; not recursively deleting it."
          return 1
        fi
        rm -f -- "$target" || { warn "Could not remove failed controller at $target."; return 1; }
      fi
      ;;
    directory)
      # If the original directory was not moved, it is still in place. If it was moved, the
      # first branch restores it. Never recursively remove a directory in this privileged path.
      if [[ -d "$target" && ! -L "$target" ]]; then return 0; fi
      warn "Original controller path was a directory; inspect $LEGACY_CONTROLLER_PATH and $target."
      return 1
      ;;
    *) warn 'Controller rollback metadata is missing; manual verification is required.'; return 1;;
  esac
}
restore_previous(){
  local f
  log 'Attempting source/unit/controller rollback from the external snapshot.'
  if (( WAS_ENABLED == 0 )); then systemctl disable "$SERVICE_NAME" >/dev/null 2>&1 || true; fi
  for f in "${CODE_FILES[@]}"; do
    if [[ -f "$BACKUP_DIR/$f" ]]; then
      cp -p -- "$BACKUP_DIR/$f" "$APP_DIR/.$f.rollback.$$" && mv -f -- "$APP_DIR/.$f.rollback.$$" "$APP_DIR/$f" || warn "Could not restore $f from $BACKUP_DIR."
    elif [[ -f "$BACKUP_DIR/.absent-$f" ]]; then
      rm -f -- "$APP_DIR/$f" || warn "Could not remove newly installed $f during rollback."
    fi
  done
  if [[ "$UNIT_ORIGINAL_TYPE" == symlink && -L "$BACKUP_DIR/unit-object" ]]; then
    local unit_restore_tmp="/etc/systemd/system/.${SERVICE_NAME}.rollback.$$"
    if cp -a -- "$BACKUP_DIR/unit-object" "$unit_restore_tmp" && mv -fT -- "$unit_restore_tmp" "$SYSTEMD_UNIT_PATH"; then :; else
      rm -f -- "$unit_restore_tmp" 2>/dev/null || true
      warn 'Could not restore the previous systemd unit symlink.'
    fi
  elif [[ -f "$BACKUP_DIR/bot.service" ]]; then
    local unit_restore_tmp="/etc/systemd/system/.${SERVICE_NAME}.rollback.$$"
    if cp -p -- "$BACKUP_DIR/bot.service" "$unit_restore_tmp" && mv -fT -- "$unit_restore_tmp" "$SYSTEMD_UNIT_PATH"; then :; else
      rm -f -- "$unit_restore_tmp" 2>/dev/null || true
      warn 'Could not restore the previous systemd unit atomically.'
    fi
  elif [[ "$UNIT_ORIGINAL_TYPE" == absent ]]; then
    if [[ -d "$SYSTEMD_UNIT_PATH" && ! -L "$SYSTEMD_UNIT_PATH" ]]; then
      warn "Unexpected directory at $SYSTEMD_UNIT_PATH; not recursively deleting it."
    else
      rm -f -- "$SYSTEMD_UNIT_PATH" || warn 'Could not remove newly installed systemd unit.'
    fi
  fi
  restore_controller || true
  if [[ -f "$BACKUP_DIR/fail2ban-sshd.local" ]]; then
    install -d -m 0755 "$(dirname "$FAIL2BAN_JAIL_FILE")"
    cp -p -- "$BACKUP_DIR/fail2ban-sshd.local" "$FAIL2BAN_JAIL_FILE" || warn 'Could not restore the prior Fail2ban policy.'
  elif [[ -f "$BACKUP_DIR/.absent-fail2ban-sshd.local" ]]; then
    rm -f -- "$FAIL2BAN_JAIL_FILE" || warn 'Could not remove newly installed Fail2ban policy.'
  fi
  if command -v fail2ban-client >/dev/null 2>&1 && systemctl is-active --quiet fail2ban 2>/dev/null; then
    fail2ban-client -t >/dev/null 2>&1 && systemctl restart fail2ban >/dev/null 2>&1 || true
  fi
  restore_env_config
  systemctl daemon-reload >/dev/null 2>&1 || true
  if (( WAS_ENABLED )); then systemctl enable "$SERVICE_NAME" >/dev/null 2>&1 || true; else systemctl disable "$SERVICE_NAME" >/dev/null 2>&1 || true; fi
  if (( WAS_ACTIVE )); then systemctl restart "$SERVICE_NAME" >/dev/null 2>&1 || warn "Previous service could not be restarted automatically; inspect: systemctl status $SERVICE_NAME"; fi
}

cleanup(){
  [[ -z "${STAGE_DIR:-}" ]] || rm -rf -- "$STAGE_DIR"
  [[ -z "${CTL_TMP:-}" ]] || rm -f -- "$CTL_TMP"
  [[ -z "${UNIT_TMP:-}" ]] || rm -f -- "$UNIT_TMP"
  [[ -z "${JAIL_TMP:-}" ]] || rm -f -- "$JAIL_TMP"
  [[ -z "${ENV_BACKUP_TMP:-}" ]] || rm -f -- "$ENV_BACKUP_TMP"
}
trap 'rc=$?; if (( rc != 0 )); then if (( ROLLBACK_ARMED == 1 )); then restore_previous; elif (( CONFIG_ROLLBACK_ARMED == 1 )); then restore_env_config; fi; fi; cleanup; if (( rc != 0 )); then warn "Setup failed (exit $rc). Snapshot: $BACKUP_DIR"; fi; exit "$rc"' EXIT

# Snapshot only code files and system controller/unit; .env and runtime VPS data are never replaced.
step 'Preparing a protected rollback snapshot (code/unit/controller only; VM data is preserved)...'
for f in "${CODE_FILES[@]}"; do
  if [[ -f "$APP_DIR/$f" ]]; then cp -p -- "$APP_DIR/$f" "$BACKUP_DIR/$f"; else : > "$BACKUP_DIR/.absent-$f"; fi
done
if [[ -L "$SYSTEMD_UNIT_PATH" ]]; then
  UNIT_ORIGINAL_TYPE=symlink; cp -a -- "$SYSTEMD_UNIT_PATH" "$BACKUP_DIR/unit-object"
elif [[ -d "$SYSTEMD_UNIT_PATH" ]]; then
  die "Unexpected directory at $SYSTEMD_UNIT_PATH; refusing to install a unit into a directory."
elif [[ -f "$SYSTEMD_UNIT_PATH" ]]; then
  UNIT_ORIGINAL_TYPE=file; cp -p -- "$SYSTEMD_UNIT_PATH" "$BACKUP_DIR/bot.service"
elif [[ -e "$SYSTEMD_UNIT_PATH" ]]; then
  die "Unsupported special filesystem object exists at $SYSTEMD_UNIT_PATH."
else
  UNIT_ORIGINAL_TYPE=absent
fi
printf '%s\n' "$UNIT_ORIGINAL_TYPE" > "$BACKUP_DIR/unit-object.type"
if [[ -L /usr/local/sbin/vpsctl ]]; then
  CONTROLLER_ORIGINAL_TYPE=symlink; cp -a -- /usr/local/sbin/vpsctl "$BACKUP_DIR/vpsctl-object"
elif [[ -d /usr/local/sbin/vpsctl ]]; then
  CONTROLLER_ORIGINAL_TYPE=directory
elif [[ -f /usr/local/sbin/vpsctl ]]; then
  CONTROLLER_ORIGINAL_TYPE=file; cp -a -- /usr/local/sbin/vpsctl "$BACKUP_DIR/vpsctl-object"
elif [[ -e /usr/local/sbin/vpsctl ]]; then
  die 'Unsupported special filesystem object exists at /usr/local/sbin/vpsctl; refusing to replace it.'
else
  CONTROLLER_ORIGINAL_TYPE=absent
fi
printf '%s\n' "$CONTROLLER_ORIGINAL_TYPE" > "$BACKUP_DIR/vpsctl-object.type"
if [[ -f "$FAIL2BAN_JAIL_FILE" ]]; then cp -p -- "$FAIL2BAN_JAIL_FILE" "$BACKUP_DIR/fail2ban-sshd.local"; else : > "$BACKUP_DIR/.absent-fail2ban-sshd.local"; fi

# Preserve database using SQLite's online backup API; original DB/WAL/SHM stay in place.
LIVE_DB=''
if [[ -f "$DATA_DIR/vps.db" ]]; then LIVE_DB="$DATA_DIR/vps.db"; elif [[ -f "$APP_DIR/vps.db" ]]; then LIVE_DB="$APP_DIR/vps.db"; fi
if [[ -n "$LIVE_DB" ]]; then
  python3 - "$LIVE_DB" "$BACKUP_ROOT/db-snapshots/$STAMP-vps.db" <<'PYDB'
import os,sqlite3,sys
src,dst=sys.argv[1:]
s=sqlite3.connect(src,timeout=30)
try:
 d=sqlite3.connect(dst)
 try: s.backup(d)
 finally: d.close()
finally: s.close()
os.chmod(dst,0o600)
print('SQLite online backup created; source DB/WAL/SHM were not altered.')
PYDB
fi

if [[ -L "$ENV_FILE" ]]; then die "Refusing .env symlink at $ENV_FILE; replace it with a regular file so chmod and rollback cannot alter an external target."; fi
if [[ -f "$ENV_FILE" ]]; then
  cp -p -- "$ENV_FILE" "$BACKUP_DIR/.env-original"
  chmod 0600 "$BACKUP_DIR/.env-original"
  ENV_ORIGINAL_PRESENT=1
  CONFIG_ROLLBACK_ARMED=1
fi
if [[ "$SOURCE_DIR" != "$APP_DIR" && ! -f "$ENV_FILE" ]]; then
  cp -- "$SOURCE_DIR/.env" "$ENV_FILE"
fi
[[ -f "$ENV_FILE" && ! -L "$ENV_FILE" ]] || die "No regular .env file exists at $ENV_FILE. Restore the .env file from the release bundle."
chmod 0600 "$ENV_FILE"
MOTD_CONFIG="$(config_get AUTO_MOTD_INSTALLER "$ENV_FILE")"
case "${MOTD_CONFIG,,}" in 0|false|no|off) log 'Guest MOTD installer is disabled by the existing .env setting AUTO_MOTD_INSTALLER.' ;; *) log 'Guest MOTD: auto-install is enabled by .env/default; RGNODES safe profile script is applied during VPS provisioning (no upstream curl|bash execution).' ;; esac
log "Using existing configuration: $ENV_FILE (it will not be replaced)."
log "Persistent VM state: $STATE_ROOT; bot data: $DATA_DIR."

# Small atomic key/value editor. It does not echo secret values into the setup log.
env_get(){ python3 - "$1" "$ENV_FILE" <<'PYGET'
import sys
key,path=sys.argv[1:]
try:
 for line in open(path,encoding='utf-8',errors='replace'):
  s=line.strip()
  if s and not s.startswith('#') and '=' in s:
   k,v=s.split('=',1)
   if k.strip()==key: print(v.strip().strip('"').strip("'")); break
except OSError: pass
PYGET
}
token_is_ready(){
  python3 - "$ENV_FILE" <<'PYTOKENCHECK'
import sys
from pathlib import Path
values={}
for line in Path(sys.argv[1]).read_text(encoding='utf-8', errors='replace').splitlines():
    row=line.strip()
    if row and not row.startswith('#') and '=' in row:
        key,value=row.split('=',1)
        values[key.strip()]=value.strip().strip('"\'')
token=values.get('DISCORD_TOKEN','')
known={'','paste_your_discord_bot_token_here','your_discord_bot_token','your_bot_token','changeme','change_me'}
raise SystemExit(0 if token.lower() not in known and len(token)>=50 and token.isascii() and not any(ch.isspace() for ch in token) else 1)
PYTOKENCHECK
}
env_set(){ python3 - "$1" "$2" "$ENV_FILE" <<'PYSET'
import os,sys,tempfile
from pathlib import Path
key,value,path=sys.argv[1:]
p=Path(path); lines=p.read_text(encoding='utf-8',errors='replace').splitlines(); out=[]; seen=False
for line in lines:
 s=line.strip()
 if s and not s.startswith('#') and '=' in s and s.split('=',1)[0].strip()==key:
  if not seen: out.append(f'{key}={value}'); seen=True
 else: out.append(line)
if not seen: out.append(f'{key}={value}')
fd,tmp=tempfile.mkstemp(prefix='.env-rgnodes-',dir=str(p.parent))
try:
 with os.fdopen(fd,'w',encoding='utf-8') as f: f.write('\n'.join(out)+'\n'); f.flush(); os.fsync(f.fileno())
 os.chmod(tmp,0o600); os.replace(tmp,p)
finally:
 try: os.unlink(tmp)
 except FileNotFoundError: pass
PYSET
}
env_remove(){ python3 - "$1" "$ENV_FILE" <<'PYREMOVE'
import os,sys,tempfile
from pathlib import Path
key,path=sys.argv[1:]
p=Path(path); lines=p.read_text(encoding='utf-8',errors='replace').splitlines(); out=[]
for line in lines:
 s=line.strip()
 if s and not s.startswith('#') and '=' in s and s.split('=',1)[0].strip()==key: continue
 out.append(line)
fd,tmp=tempfile.mkstemp(prefix='.env-rgnodes-remove-',dir=str(p.parent))
try:
 with os.fdopen(fd,'w',encoding='utf-8') as f: f.write('\n'.join(out)+'\n'); f.flush(); os.fsync(f.fileno())
 os.chmod(tmp,0o600); os.replace(tmp,p)
finally:
 try: os.unlink(tmp)
 except FileNotFoundError: pass
PYREMOVE
}
# Migrate only the previous release's shipped defaults; retain any custom operator values.
# This upgrades default VPS sizing to 8/2/25, permits admin provisioning up to 22/10/100,
# and disables frequent auto-scaling to protect the control host from unnecessary work.
migrate_legacy_default(){
  local key="$1" old="$2" new="$3" current
  current="$(env_get "$key")"
  if [[ "$current" == "$old" ]]; then
    env_set "$key" "$new"
    log "Migrated legacy default $key to the new protected policy."
  fi
}
migrate_legacy_default MAX_VPS_RAM_GB 8 22
migrate_legacy_default VPS_MAX_RAM_GB 8 22
migrate_legacy_default MAX_VPS_CPU 8 10
migrate_legacy_default VPS_MAX_CPU 8 10
migrate_legacy_default INITIAL_VPS_RAM_GB 1 8
migrate_legacy_default DEFAULT_VPS_RAM_GB 1 8
migrate_legacy_default INITIAL_VPS_CPU 1 2
migrate_legacy_default DEFAULT_VPS_CPU 1 2
migrate_legacy_default INITIAL_VPS_DISK_GB 10 25
migrate_legacy_default DEFAULT_VPS_STORAGE_GB 10 25
migrate_legacy_default MAX_VPS_DISK_GB 50 100
# One-time migration: disable the old autoscale-on/30-second default, but preserve a deliberate
# operator opt-in later when the interval is already at the new safe 300-second floor.
if [[ "$(env_get RESOURCE_AUTOSCALE_ENABLED | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ && "$(env_get RESOURCE_AUTOSCALE_INTERVAL)" == 30 ]]; then
  env_set RESOURCE_AUTOSCALE_ENABLED false
  log 'Migrated the legacy autoscale-on/30-second defaults to the safer low-load policy.'
fi
migrate_legacy_default RESOURCE_AUTOSCALE_INTERVAL 30 300

# Seed absent/blank settings, then constrain and reconcile the values exactly as bot.py consumes
# them. This prevents conflicting legacy aliases from showing one limit while applying another.
ensure_env_default(){ [[ -n "$(env_get "$1")" ]] || env_set "$1" "$2"; }
valid_bot_display_name(){ python3 - "$1" <<'PYBOTNAME'
import sys
name=sys.argv[1]
blocked=set('=#$\\\"\'`')
if not 2 <= len(name) <= 32 or any(ord(ch)<32 or ord(ch)==127 for ch in name) or any(ch in blocked for ch in name):
    raise SystemExit(1)
PYBOTNAME
}
for kv in   'MIN_VPS_RAM_GB=1' 'INITIAL_VPS_RAM_GB=8' 'DEFAULT_VPS_RAM_GB=8' 'MAX_VPS_RAM_GB=22'   'INITIAL_VPS_CPU=2' 'DEFAULT_VPS_CPU=2' 'MAX_VPS_CPU=10'   'MIN_VPS_DISK_GB=10' 'INITIAL_VPS_DISK_GB=25' 'DEFAULT_VPS_STORAGE_GB=25' 'MAX_VPS_DISK_GB=100'   'RESOURCE_AUTOSCALE_ENABLED=false' 'RESOURCE_AUTOSCALE_INTERVAL=300'   'WEB_TERMINAL_ENABLED=true' 'WEB_TERMINAL_PORT=909' 'WEB_TERMINAL_PUBLIC_URL=https://ssh.rgnodes.bond' 'WEB_TERMINAL_MAX_SESSIONS=3' 'HOST_DOCKER_ENABLED=false' 'HOST_LXC_TOOLS_ENABLED=false' 'HOST_FASTFETCH_ENABLED=false' 'LOCAL_KVM_ENABLED=false' 'NODE_LOCATION_AUTO_DETECT=true'   'BOT_CPU_QUOTA_PERCENT=100' 'BOT_MEMORY_MAX_MB=1024' 'BOT_TASKS_MAX=512' 'DEFAULT_STORAGE_POOL=default' 'VPS_BACKUP_DIR=vps_backups' 'DEPLOY_NODE_SERIALIZE=true' 'GUEST_ACCESS_RETRY_INTERVAL=300' 'MAX_BACKGROUND_REPAIR_CONCURRENCY=2' 'TUNNEL_START_TIMEOUT=65' 'LOG_CHANNEL_SNAPSHOT_LINES=16' 'YOUR_SERVER_IP='; do
  ensure_env_default "${kv%%=*}" "${kv#*=}"
done
normalize_int_env(){
  local key="$1" fallback="$2" low="$3" high="$4" current normalized
  current="$(env_get "$key")"
  normalized="$(python3 - "$current" "$fallback" "$low" "$high" <<'PYNORMALIZE'
import re,sys
raw, fallback, low, high = sys.argv[1:]
lo, hi = int(low), int(high)
try:
    value = int(raw, 10) if re.fullmatch(r'[0-9]{1,9}', raw) else int(fallback, 10)
except ValueError:
    value = int(fallback, 10)
print(max(lo, min(hi, value)))
PYNORMALIZE
)"
  if [[ "$current" != "$normalized" ]]; then
    env_set "$key" "$normalized"
    warn "Normalized $key to the safe supported range $low-$high (effective value: $normalized)."
  fi
}
normalize_int_env MAX_VPS_RAM_GB 22 1 22
normalize_int_env MIN_VPS_RAM_GB 1 1 "$(env_get MAX_VPS_RAM_GB)"
normalize_int_env INITIAL_VPS_RAM_GB 8 "$(env_get MIN_VPS_RAM_GB)" "$(env_get MAX_VPS_RAM_GB)"
normalize_int_env DEFAULT_VPS_RAM_GB 8 "$(env_get MIN_VPS_RAM_GB)" "$(env_get MAX_VPS_RAM_GB)"
normalize_int_env MAX_VPS_CPU 10 1 10
normalize_int_env INITIAL_VPS_CPU 2 1 "$(env_get MAX_VPS_CPU)"
normalize_int_env DEFAULT_VPS_CPU 2 1 "$(env_get MAX_VPS_CPU)"
normalize_int_env MIN_VPS_DISK_GB 10 5 100
normalize_int_env MAX_VPS_DISK_GB 100 "$(env_get MIN_VPS_DISK_GB)" 100
normalize_int_env INITIAL_VPS_DISK_GB 25 "$(env_get MIN_VPS_DISK_GB)" "$(env_get MAX_VPS_DISK_GB)"
normalize_int_env DEFAULT_VPS_STORAGE_GB 25 "$(env_get MIN_VPS_DISK_GB)" "$(env_get MAX_VPS_DISK_GB)"
normalize_int_env RESOURCE_AUTOSCALE_INTERVAL 300 300 86400
normalize_int_env WEB_TERMINAL_PORT 909 1 65535
normalize_int_env WEB_TERMINAL_MAX_SESSIONS 3 1 8
normalize_int_env BOT_CPU_QUOTA_PERCENT 100 25 200
normalize_int_env BOT_MEMORY_MAX_MB 1024 512 4096
normalize_int_env BOT_TASKS_MAX 512 128 2048
normalize_int_env GUEST_ACCESS_RETRY_INTERVAL 300 120 86400
normalize_int_env MAX_BACKGROUND_REPAIR_CONCURRENCY 2 1 4
normalize_int_env TUNNEL_START_TIMEOUT 65 25 600
normalize_int_env LOG_CHANNEL_SNAPSHOT_LINES 16 8 30
# .env remains data, never sourced as shell code; copy only validated numeric values to variables
# used to render the systemd unit below.
BOT_CPU_QUOTA_PERCENT="$(env_get BOT_CPU_QUOTA_PERCENT)"
BOT_MEMORY_MAX_MB="$(env_get BOT_MEMORY_MAX_MB)"
BOT_TASKS_MAX="$(env_get BOT_TASKS_MAX)"
sync_resource_alias(){
  local alias_key="$1" source_key="$2" source_value current
  source_value="$(env_get "$source_key")"; current="$(env_get "$alias_key")"
  if [[ "$current" != "$source_value" ]]; then env_set "$alias_key" "$source_value"; log "Aligned $alias_key with $source_key to keep runtime limits consistent."; fi
}
sync_resource_alias VPS_MAX_RAM_GB MAX_VPS_RAM_GB
sync_resource_alias VPS_MAX_CPU MAX_VPS_CPU
if [[ "$(env_get RESOURCE_AUTOSCALE_ENABLED | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]]; then
  warn 'RESOURCE_AUTOSCALE_ENABLED is true. The low-load safe default is false; retaining the explicit operator setting.'
fi

# Refresh release metadata. Combined Local + Remote routing is a fixed invariant; there is no
# local and remote nodes are both supported. Host KVM installation is controlled separately by
# LOCAL_KVM_ENABLED so a constrained control VPS can use remote nodes without nested virtualization.
PREVIOUS_BOT_VERSION="$(env_get BOT_VERSION)"
env_remove REMOTE_NODE_ONLY
env_remove BOT_DEVELOPER
env_remove VPS_HOSTNAME
env_set BOT_VERSION '9.3.1 RGNODES VPS Deploying Manager Pro'
ensure_env_default LOCAL_KVM_ENABLED false
ensure_env_default NODE_LOCATION_AUTO_DETECT true
[[ -n "$(env_get DEFAULT_NODE_ID)" ]] || env_set DEFAULT_NODE_ID '0'
env_set PINGGY_SSH_PORT '443'
env_set PINGGY_REMOTE_PORT '890'
env_set WEB_TERMINAL_PUBLIC_URL 'https://ssh.rgnodes.bond'
[[ -n "$(env_get HOST_VCPU_OVERCOMMIT_RATIO)" ]] || env_set HOST_VCPU_OVERCOMMIT_RATIO '1.5'
[[ -n "$(env_get MAX_DEPLOY_RAM_SHARE)" ]] || env_set MAX_DEPLOY_RAM_SHARE '0.80'
[[ -n "$(env_get HOST_CPU_RESERVE)" ]] || env_set HOST_CPU_RESERVE '1'
[[ -n "$(env_get HOST_RAM_RESERVE_GB)" ]] || env_set HOST_RAM_RESERVE_GB '2'
[[ -n "$(env_get HOST_DISK_RESERVE_GB)" ]] || env_set HOST_DISK_RESERVE_GB '10'
[[ -n "$(env_get HOST_CPU_MAX_DEPLOY_PCT)" ]] || env_set HOST_CPU_MAX_DEPLOY_PCT '85'
[[ -n "$(env_get MIN_HOST_RAM_FREE_PCT_DEPLOY)" ]] || env_set MIN_HOST_RAM_FREE_PCT_DEPLOY '18'

# Interactive first run. Secrets are hidden, IDs and resource values are validated, and an
# upgrade does not repeatedly prompt for host options unless RGNODES_SETUP_WIZARD=1 is supplied.
prompt_yes_no(){
  local question="$1" default="${2:-no}" reply hint
  if [[ "$default" == "yes" ]]; then hint='[Y/n]'; else hint='[y/N]'; fi
  printf '%s %s ' "$question" "$hint" >/dev/tty
  IFS= read -r reply </dev/tty || reply=''
  reply="$(printf '%s' "$reply" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')"
  if [[ -z "$reply" ]]; then [[ "$default" == "yes" ]]; return $?; fi
  case "$reply" in y|yes) return 0;; n|no) return 1;; *) warn 'Please answer Y or N; using the safe default.'; [[ "$default" == "yes" ]]; return $?;; esac
}

prompt_resource(){
  local key_initial="$1" key_default="$2" label="$3" low="$4" high="$5" current answer answer_num
  current="$(env_get "$key_default")"
  [[ "$current" =~ ^[0-9]+$ ]] || current="$low"
  printf 'Default VPS %s [%s, allowed %s-%s]: ' "$label" "$current" "$low" "$high" >/dev/tty
  IFS= read -r answer </dev/tty || answer=''
  answer="$(printf '%s' "$answer" | tr -d '[:space:]')"
  [[ -n "$answer" ]] || answer="$current"
  if [[ ! "$answer" =~ ^[0-9]{1,3}$ ]]; then
    warn "Invalid $label value; retaining $current (allowed $low-$high)."
    return 0
  fi
  answer_num=$((10#$answer))
  if (( answer_num < low || answer_num > high )); then
    warn "Invalid $label value; retaining $current (allowed $low-$high)."
    return 0
  fi
  answer="$answer_num"
  env_set "$key_initial" "$answer"
  env_set "$key_default" "$answer"
  log "Default VPS $label set to $answer."
}

prompt_bool_env(){
  local key="$1" question="$2" default="$3" result
  if prompt_yes_no "$question" "$default"; then result=true; else result=false; fi
  env_set "$key" "$result"
}

DO_FULL_UPGRADE=0
case "$(printf '%s' "${RGNODES_FULL_UPGRADE:-}" | tr '[:upper:]' '[:lower:]')" in 1|true|yes|on) DO_FULL_UPGRADE=1;; esac
if [[ -t 0 && -r /dev/tty ]]; then
  if ! token_is_ready; then
    printf '🔐 Paste DISCORD_TOKEN (hidden; Enter keeps current value): ' >/dev/tty
    IFS= read -r -s INPUT_TOKEN </dev/tty || INPUT_TOKEN=''; printf '\n' >/dev/tty
    INPUT_TOKEN="$(printf '%s' "$INPUT_TOKEN" | tr -d '\r\n')"
    [[ -z "$INPUT_TOKEN" ]] || env_set DISCORD_TOKEN "$INPUT_TOKEN"
    unset INPUT_TOKEN
  fi
  ADMIN_CURRENT="$(env_get MAIN_ADMIN_ID)"
  if [[ ! "$ADMIN_CURRENT" =~ ^[0-9]{15,22}$ ]] || (( WIZARD_ACTIVE )); then
    printf '👑 Enter MAIN_ADMIN_ID (15-22 digit Discord user ID; Enter keeps current): ' >/dev/tty
    IFS= read -r INPUT_ADMIN </dev/tty || INPUT_ADMIN=''
    INPUT_ADMIN="$(printf '%s' "$INPUT_ADMIN" | tr -d '[:space:]')"
    if [[ "$INPUT_ADMIN" =~ ^[0-9]{15,22}$ ]]; then env_set MAIN_ADMIN_ID "$INPUT_ADMIN"; elif [[ -n "$INPUT_ADMIN" ]]; then warn 'MAIN_ADMIN_ID must be a 15-22 digit Discord ID; left unchanged.'; fi
    unset INPUT_ADMIN
  fi
  if (( WIZARD_ACTIVE )); then
    printf '🛡 Additional ADMIN_USER_IDS (comma-separated IDs, Enter keeps current): ' >/dev/tty
    IFS= read -r INPUT_ADMINS </dev/tty || INPUT_ADMINS=''
    if [[ -n "${INPUT_ADMINS//[[:space:],]/}" ]]; then
      INPUT_ADMINS="$(printf '%s' "$INPUT_ADMINS" | tr -d '[:space:]')"
      if python3 - "$INPUT_ADMINS" <<'PYADMININPUT'
import re,sys
value=sys.argv[1]
items=value.split(',')
raise SystemExit(0 if items and all(re.fullmatch(r'[0-9]{15,22}',x) for x in items) else 1)
PYADMININPUT
      then
        INPUT_ADMINS="$(python3 - "$INPUT_ADMINS" <<'PYADMINDEDUP'
import sys
seen=[]
for item in sys.argv[1].split(','):
 if item not in seen: seen.append(item)
print(','.join(seen))
PYADMINDEDUP
)"
        env_set ADMIN_USER_IDS "$INPUT_ADMINS"
      else
        warn 'One or more additional admin IDs were invalid; ADMIN_USER_IDS was not changed.'
      fi
    fi
    unset INPUT_ADMINS

    prompt_resource INITIAL_VPS_RAM_GB DEFAULT_VPS_RAM_GB '🧠 RAM in GiB' 1 "$(env_get MAX_VPS_RAM_GB)"
    prompt_resource INITIAL_VPS_CPU DEFAULT_VPS_CPU '⚙️ CPU cores' 1 "$(env_get MAX_VPS_CPU)"
    prompt_resource INITIAL_VPS_DISK_GB DEFAULT_VPS_STORAGE_GB '💾 disk in GiB' "$(env_get MIN_VPS_DISK_GB)" "$(env_get MAX_VPS_DISK_GB)"

    LOCAL_KVM_DEFAULT=no
    [[ "$(env_get LOCAL_KVM_ENABLED | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]] && LOCAL_KVM_DEFAULT=yes
    if prompt_yes_no '🧩 Install KVM/QEMU/libvirt on THIS control host? (No keeps host lean; Local Node still registers and remote nodes remain available)' "$LOCAL_KVM_DEFAULT"; then
      env_set LOCAL_KVM_ENABLED true
    else
      env_set LOCAL_KVM_ENABLED false
    fi

    CURRENT_BOT_NAME="$(env_get BOT_NAME)"; [[ -n "$CURRENT_BOT_NAME" ]] || CURRENT_BOT_NAME='RGNODES™'
    printf '🤖 Bot display name [%s] (Enter keeps it; 2-32 chars): ' "$CURRENT_BOT_NAME" >/dev/tty
    IFS= read -r INPUT_BOT_NAME </dev/tty || INPUT_BOT_NAME=''
    if [[ -n "$INPUT_BOT_NAME" ]]; then
      if valid_bot_display_name "$INPUT_BOT_NAME"; then
        env_set BOT_NAME "$INPUT_BOT_NAME"
        log 'Bot display name updated. The immutable developer identity remains unchanged.'
      else
        warn 'Bot display name must be 2-32 characters on one line; existing name retained.'
      fi
    fi
    unset INPUT_BOT_NAME CURRENT_BOT_NAME

    CURRENT_PREFIX="$(env_get PREFIX)"; [[ -n "$CURRENT_PREFIX" ]] || CURRENT_PREFIX='-'
    printf '⌨️ Bot command prefix [%s] (Enter keeps it; use e.g. -): ' "$CURRENT_PREFIX" >/dev/tty
    IFS= read -r INPUT_PREFIX </dev/tty || INPUT_PREFIX=''
    if [[ -n "$INPUT_PREFIX" ]]; then
      if [[ "$INPUT_PREFIX" =~ ^[^[:space:]=]{1,8}$ ]]; then env_set PREFIX "$INPUT_PREFIX"; else warn 'Prefix must be 1-8 visible non-space characters without =; existing prefix retained.'; fi
    fi
    unset INPUT_PREFIX CURRENT_PREFIX

    PINGGY_DEFAULT=no
    [[ "$(env_get PINGGY_ENABLED | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]] && PINGGY_DEFAULT=yes
    if prompt_yes_no '🚇 Enable Pinggy SSH tunneling for deployed VPSs?' "$PINGGY_DEFAULT"; then
      env_set PINGGY_ENABLED true; env_set PINGGY_AUTO_START true
    else
      env_set PINGGY_ENABLED false; env_set PINGGY_AUTO_START false
    fi
    IP_DEFAULT=no
    [[ "$(env_get AUTO_DETECT_PUBLIC_IP | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]] && IP_DEFAULT=yes
    prompt_bool_env AUTO_DETECT_PUBLIC_IP '🌐 Auto-detect the control/node public IPv4 when supported?' "$IP_DEFAULT"
    REQUIRE_IP_DEFAULT=yes
    [[ "$(env_get REAL_PUBLIC_IPV4_REQUIRED | tr '[:upper:]' '[:lower:]')" =~ ^(0|false|no|off)$ ]] && REQUIRE_IP_DEFAULT=no
    prompt_bool_env REAL_PUBLIC_IPV4_REQUIRED '📡 Require a real public IPv4 before deployment succeeds?' "$REQUIRE_IP_DEFAULT"

    DOCKER_DEFAULT=no
    if [[ "$(env_get HOST_DOCKER_ENABLED | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]]; then DOCKER_DEFAULT=yes; fi
    if prompt_yes_no '🐳 Install and enable Docker Engine on this control host? (Docker-in-guest remains separate)' "$DOCKER_DEFAULT"; then env_set HOST_DOCKER_ENABLED true; else env_set HOST_DOCKER_ENABLED false; fi
    LXC_DEFAULT=no
    if [[ "$(env_get HOST_LXC_TOOLS_ENABLED | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]]; then LXC_DEFAULT=yes; fi
    if prompt_yes_no '📦 Install LXC tools on this host? (RGNODES VPS backend stays KVM/QEMU)' "$LXC_DEFAULT"; then env_set HOST_LXC_TOOLS_ENABLED true; else env_set HOST_LXC_TOOLS_ENABLED false; fi
    FASTFETCH_DEFAULT=no
    if [[ "$(env_get HOST_FASTFETCH_ENABLED | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]]; then FASTFETCH_DEFAULT=yes; fi
    if prompt_yes_no '✨ Install Neofetch or Fastfetch for diagnostics?' "$FASTFETCH_DEFAULT"; then env_set HOST_FASTFETCH_ENABLED true; else env_set HOST_FASTFETCH_ENABLED false; fi

    warn 'A full OS upgrade can restart services or require a reboot. It is separate from the safe dependency install.'
    if [[ "$DO_FULL_UPGRADE" != 1 ]] && prompt_yes_no '⬆️ Run apt-get full-upgrade now?' 'no'; then DO_FULL_UPGRADE=1; fi
  fi
fi

ADMIN_ID_CHECK="$(env_get MAIN_ADMIN_ID)"
if [[ -n "$ADMIN_ID_CHECK" && ! "$ADMIN_ID_CHECK" =~ ^[0-9]{15,22}$ ]]; then
  die 'MAIN_ADMIN_ID must be a 15-22 digit Discord user ID. Correct .env before installing.'
fi
ADMIN_LIST_CHECK="$(env_get ADMIN_USER_IDS)"
if [[ -n "$ADMIN_LIST_CHECK" ]]; then
  python3 - "$ADMIN_LIST_CHECK" <<'PYADMINVALIDATE' || die 'ADMIN_USER_IDS must be a comma-separated list of 15-22 digit Discord user IDs.'
import re,sys
items=[x.strip() for x in sys.argv[1].split(',')]
if not items or any(not re.fullmatch(r'[0-9]{15,22}',x) for x in items): raise SystemExit(1)
PYADMINVALIDATE
fi
if (( WAS_ACTIVE || WAS_ENABLED )) && ! token_is_ready; then
  die "The existing $SERVICE_NAME is active/enabled but DISCORD_TOKEN is missing or invalid. Fix .env first; refusing to stop or replace the working service."
fi
if (( WAS_ACTIVE || WAS_ENABLED )) && [[ ! "$ADMIN_ID_CHECK" =~ ^[0-9]{15,22}$ ]]; then
  die "The existing $SERVICE_NAME is active/enabled but MAIN_ADMIN_ID is missing or invalid. Fix .env first; refusing to stop or replace the working service."
fi
if ! token_is_ready; then warn 'DISCORD_TOKEN is not ready. Code can be installed, but the service will remain disabled until a valid token is configured.'; fi
if [[ ! "$ADMIN_ID_CHECK" =~ ^[0-9]{15,22}$ ]]; then warn 'MAIN_ADMIN_ID is not ready. Configure a valid numeric Discord user ID; the bot service will remain disabled until both token and admin are valid.'; fi
log "VPS defaults: $(env_get DEFAULT_VPS_RAM_GB) GiB RAM / $(env_get DEFAULT_VPS_CPU) CPU / $(env_get DEFAULT_VPS_STORAGE_GB) GiB disk. Admin ceilings: $(env_get MAX_VPS_RAM_GB) GiB / $(env_get MAX_VPS_CPU) CPU / $(env_get MAX_VPS_DISK_GB) GiB disk."
log "Feature policy: Pinggy=$(env_get PINGGY_ENABLED), public-IP autodetect=$(env_get AUTO_DETECT_PUBLIC_IP), host Docker=$(env_get HOST_DOCKER_ENABLED), host LXC=$(env_get HOST_LXC_TOOLS_ENABLED), terminal=$(env_get WEB_TERMINAL_PUBLIC_URL)."

# A full OS upgrade is always opt-in. Automation may explicitly approve it with
# RGNODES_FULL_UPGRADE=1; non-interactive runs never infer consent from a missing TTY.
DO_FULL_UPGRADE="${DO_FULL_UPGRADE:-0}"
# Auto-detect a default-route NIC only; do not alter interfaces, routes, bridges or provider firewall.
if [[ -z "$(env_get PUBLIC_PARENT_INTERFACE)" && -z "$(env_get PUBLIC_BRIDGE_NAME)" && "$(env_get KVM_NETWORK_MODE)" != bridge ]]; then
  UPLINK="$(ip -4 route show default 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}' || true)"
  if [[ -n "$UPLINK" ]]; then env_set PUBLIC_PARENT_INTERFACE "$UPLINK"; log "Detected uplink $UPLINK and saved it as PUBLIC_PARENT_INTERFACE."; else warn 'Public uplink not detected; set PUBLIC_PARENT_INTERFACE or configure a provider-created PUBLIC_BRIDGE_NAME.'; fi
fi
# Save the effective config after hidden token/admin prompts and safe uplink detection, so a
# first-install credential is actually present in the private backup. Never expose it in logs.
ENV_BACKUP_TMP="$(mktemp "$DATA_DIR/.env-backup.rgnodes.XXXXXX")"
install -m 0600 "$ENV_FILE" "$ENV_BACKUP_TMP"
mv -fT -- "$ENV_BACKUP_TMP" "$DATA_DIR/env.backup"
ENV_BACKUP_TMP=''

# Install required bot/runtime packages only. Local KVM is an explicit optional host feature;
# remote node support remains available regardless of that selection.
apt_retry(){
  local attempt=1 delay=3
  while (( attempt <= 3 )); do
    if "$@"; then return 0; fi
    if (( attempt == 3 )); then return 1; fi
    warn "Command failed (attempt $attempt/3): $*; retrying in ${delay}s."
    sleep "$delay"
    attempt=$((attempt + 1)); delay=$((delay + 3))
  done
  return 1
}
if [[ "$MODE" != "--code-only" ]]; then
  export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a APT_LISTCHANGES_FRONTEND=none
  log "OS preflight: ${PRETTY_NAME:-${ID:-Debian/Ubuntu}}; checking missing runtime packages and safe repair options."
  step 'Phase 1/6 • Detect OS and validate release/controller hashes.'
  step 'Phase 2/6 • Update package indexes; repair missing required dependencies.'
  step 'Updating package indexes (apt-get update)...'
  apt_retry apt-get update || die 'apt-get update failed after three attempts; no application service was stopped.'
  if [[ "$DO_FULL_UPGRADE" == 1 ]]; then
    warn 'Running the explicitly approved full system package upgrade. Package changes cannot be rolled back by this installer; a provider/OS reboot may be required.'
    apt_retry apt-get full-upgrade -y || die 'The requested full-upgrade failed. Review apt history and package-manager logs before retrying.'
    step 'Full system upgrade completed.'
  else
    log 'Full system upgrade skipped; only named dependencies will be installed/repaired, avoiding surprise host-wide changes.'
  fi

  HOST_DOCKER_ENABLED="$(env_get HOST_DOCKER_ENABLED | tr '[:upper:]' '[:lower:]')"
  HOST_LXC_TOOLS_ENABLED="$(env_get HOST_LXC_TOOLS_ENABLED | tr '[:upper:]' '[:lower:]')"
  HOST_FASTFETCH_ENABLED="$(env_get HOST_FASTFETCH_ENABLED | tr '[:upper:]' '[:lower:]')"
  MISSING_COMMANDS=()
  for required_command in python3 curl openssl sqlite3 ip ping ssh; do
    command -v "$required_command" >/dev/null 2>&1 || MISSING_COMMANDS+=("$required_command")
  done
  if ((${#MISSING_COMMANDS[@]})); then
    warn "Missing command tools detected: ${MISSING_COMMANDS[*]}. The package manager will repair/install them next."
  else
    step 'Core command checks passed; apt will still reconcile package versions and dependencies.'
  fi
  step 'Finding missing required dependencies and repairing them with the package manager...'
  apt_retry apt-get install -y python3 python3-venv python3-pip python3-dev build-essential libffi-dev pkg-config \
    ca-certificates curl wget unzip openssl sqlite3 acl sudo net-tools openssh-server openssh-client sshpass iproute2 \
    iputils-ping procps util-linux nftables dnsutils fail2ban python3-systemd || die 'Required host dependencies could not be installed after three attempts.'

  # Optional host tools are installed separately: an unavailable optional package must never
  # prevent the required bot runtime from being installed. Docker is enabled only when selected.
  if [[ "$HOST_DOCKER_ENABLED" =~ ^(1|true|yes|on)$ ]]; then
    step 'Phase 3/6 • Installing/enabling optional Docker Engine on the control host...' 
    if apt_retry apt-get install -y docker.io; then
      if command -v docker >/dev/null 2>&1 && systemctl enable --now docker.service >/dev/null 2>&1 && systemctl is-active --quiet docker.service; then
        step 'Docker Engine installed, enabled at boot and active.'
      else
        warn 'Docker package installed, but its daemon did not become active; inspect `systemctl status docker` and `journalctl -u docker`.'
      fi
    else
      warn 'Optional Docker package install failed; the core bot installation will continue without host Docker.'
    fi
  fi
  if [[ "$HOST_LXC_TOOLS_ENABLED" =~ ^(1|true|yes|on)$ ]]; then
    LXC_PACKAGE=''
    if apt-cache show lxc >/dev/null 2>&1; then LXC_PACKAGE=lxc
    elif apt-cache show lxc-utils >/dev/null 2>&1; then LXC_PACKAGE=lxc-utils
    fi
    if [[ -n "$LXC_PACKAGE" ]]; then
      LXC_PACKAGES=("$LXC_PACKAGE")
      for optional_lxc_package in lxc-templates uidmap; do
        if apt-cache show "$optional_lxc_package" >/dev/null 2>&1; then LXC_PACKAGES+=("$optional_lxc_package"); fi
      done
      if apt_retry apt-get install -y "${LXC_PACKAGES[@]}"; then
        if command -v lxc-start >/dev/null 2>&1; then step 'LXC tools installed (the managed VPS backend remains KVM/QEMU).'; else warn 'LXC package installed but lxc-start is not available; check the configured repository/component.'; fi
      else
        warn 'Optional LXC tools could not be installed; the core KVM/QEMU bot installation will continue.'
      fi
    else
      warn 'No compatible LXC package was found in the enabled repositories; continuing without LXC tools.'
    fi
  fi
  if [[ "$HOST_FASTFETCH_ENABLED" =~ ^(1|true|yes|on)$ ]]; then
    FASTFETCH_PACKAGE=''
    FASTFETCH_INSTALLED=0
    for candidate_fetch in neofetch fastfetch; do
      if apt-cache show "$candidate_fetch" >/dev/null 2>&1; then
        if apt_retry apt-get install -y "$candidate_fetch"; then
          FASTFETCH_PACKAGE="$candidate_fetch"; FASTFETCH_INSTALLED=1
          step "$FASTFETCH_PACKAGE installed for optional host diagnostics."
          break
        else
          warn "Optional $candidate_fetch install failed; trying the compatible fallback if available."
        fi
      fi
    done
    if (( FASTFETCH_INSTALLED == 0 )); then warn 'Neither neofetch nor fastfetch could be installed; continuing without the optional display tool.'; fi
  fi
  if [[ "$(printf '%s' "$(env_get LOCAL_KVM_ENABLED)" | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]]; then
    step 'Installing optional local KVM/QEMU/libvirt stack on the control host...'
    apt_retry apt-get install -y cpu-checker qemu-kvm qemu-utils qemu-guest-agent \
      libvirt-daemon-system libvirt-clients libvirt-daemon-driver-qemu libvirt-daemon-config-network \
      cloud-image-utils genisoimage || die 'Optional local KVM/libvirt installation failed after three attempts.'
  else
    log 'Local KVM package installation skipped by configuration. Local Node will still register; ready pre-existing local KVM and registered remote nodes remain eligible.'
  fi
else
  log '--code-only mode: package indexes and host packages were not changed.'
  [[ "$DO_FULL_UPGRADE" != 1 ]] || warn 'Requested full-upgrade was not run because --code-only never changes host packages.'
  for option_key in HOST_DOCKER_ENABLED HOST_LXC_TOOLS_ENABLED HOST_FASTFETCH_ENABLED; do
    case "$(env_get "$option_key" | tr '[:upper:]' '[:lower:]')" in 1|true|yes|on) warn "$option_key is enabled in .env but --code-only skips package installation.";; esac
  done
fi

# Stage code outside the live paths and install Python dependencies into an isolated venv.
step 'Phase 4/6 • Validating source and preparing the isolated Python environment...' 
for f in "${CODE_FILES[@]}"; do cp -- "$SOURCE_DIR/$f" "$STAGE_DIR/$f"; done
python3 - "$STAGE_DIR/bot.py" "$STAGE_DIR/vpsctl-bin" <<'PYCTL'
import base64,hashlib,os,re,sys,tempfile,zlib
from pathlib import Path
bot,out=map(Path,sys.argv[1:])
s=bot.read_text(encoding='utf-8')
p=re.search(r"""_EMBEDDED_VPSCTL_ZLIB_B64\s*=\s*(['"])(.*?)\1""",s,re.S)
h=re.search(r"""_EMBEDDED_VPSCTL_SHA256\s*=\s*['"]([0-9a-f]{64})['"]""",s)
if not p or not h: raise SystemExit('Embedded KVM controller/hash missing')
data=zlib.decompress(base64.b64decode(p.group(2),validate=True))
if hashlib.sha256(data).hexdigest()!=h.group(1): raise SystemExit('Embedded KVM controller checksum mismatch')
text=data.decode('utf-8'); compile(text,'vpsctl','exec')
if not all(x in text for x in ('KVM/QEMU/libvirt only','def compat(','virsh')): raise SystemExit('Unexpected controller payload')
out.write_bytes(data); os.chmod(out,0o755)
print('Embedded controller extracted and verified.')
PYCTL

if [[ ! -x "$APP_DIR/.venv/bin/python" ]]; then python3 -m venv "$APP_DIR/.venv"; fi
"$APP_DIR/.venv/bin/python" -m pip install --disable-pip-version-check --retries 5 --timeout 30 --upgrade pip setuptools wheel
"$APP_DIR/.venv/bin/python" -m pip install --disable-pip-version-check --retries 5 --timeout 30 --upgrade -r "$STAGE_DIR/requirements.txt"
"$APP_DIR/.venv/bin/python" -m py_compile "$STAGE_DIR/bot.py"

# All inputs are validated and package installation is complete. From here, rollback is armed.
ROLLBACK_ARMED=1
FAIL2BAN_CONFIG_ENABLED="$(config_get HOST_FAIL2BAN_SSH_ENABLED "$ENV_FILE")"
case "${FAIL2BAN_CONFIG_ENABLED,,}" in ''|1|true|yes|on) FAIL2BAN_CONFIG_ENABLED=true;; *) FAIL2BAN_CONFIG_ENABLED=false;; esac
if [[ "$FAIL2BAN_CONFIG_ENABLED" == true ]]; then
  if command -v fail2ban-client >/dev/null 2>&1; then
    if [[ ! -e "$FAIL2BAN_JAIL_FILE" || "$(grep -Ec '^# Managed by RGNODES(™™|™) setup\.sh; SSH brute-force protection only\.$' "$FAIL2BAN_JAIL_FILE" 2>/dev/null || true)" == 1 ]]; then
      install -d -m 0755 "$(dirname "$FAIL2BAN_JAIL_FILE")"
      JAIL_TMP="$(mktemp "$(dirname "$FAIL2BAN_JAIL_FILE")/.rgnodes-sshd.XXXXXX")"
      cat > "$JAIL_TMP" <<'FAIL2BANJAIL'
# Managed by RGNODES™ setup.sh; SSH brute-force protection only.
[sshd]
enabled = true
backend = systemd
port = ssh
maxretry = 5
findtime = 10m
bantime = 1h
FAIL2BANJAIL
      chown root:root "$JAIL_TMP"; chmod 0644 "$JAIL_TMP"; mv -f -- "$JAIL_TMP" "$FAIL2BAN_JAIL_FILE"
      step 'Configured a bounded Fail2ban SSH jail (5 retries / 10-minute window / 1-hour ban).'
    else
      warn 'A non-RGNODES Fail2ban jail file already exists at the managed path; preserved it rather than overwriting custom policy.'
    fi
    if fail2ban-client -t >/dev/null 2>&1; then
      systemctl enable fail2ban >/dev/null
      systemctl restart fail2ban
      if fail2ban-client status sshd >/dev/null 2>&1; then
        step 'Fail2ban SSH jail is active; existing UFW/provider firewall and SSH authentication settings were not changed.'
      else
        warn 'Fail2ban service is active but the sshd jail is not confirmed. Review /etc/fail2ban and run fail2ban-client status.'
      fi
    else
      die 'Fail2ban configuration test failed; rollback will restore the previous jail configuration.'
    fi
  else
    warn 'Fail2ban is unavailable (most likely --code-only mode without the package). Install fail2ban to enable SSH brute-force protection.'
  fi
else
  log 'HOST_FAIL2BAN_SSH_ENABLED is disabled in .env; no Fail2ban policy was added.'
fi
if (( WAS_ACTIVE )); then log "Stopping $SERVICE_NAME for a source-safe update."; systemctl stop "$SERVICE_NAME"; fi
for f in "${CODE_FILES[@]}"; do
  chmod 0755 "$STAGE_DIR/$f" 2>/dev/null || true
  case "$f" in requirements.txt|ecosystem.config.js) chmod 0644 "$STAGE_DIR/$f";; esac
  chown root:root "$STAGE_DIR/$f"
  mv -f -- "$STAGE_DIR/$f" "$APP_DIR/$f"
done
# Setup is the only place that creates the controller executable; runtime data stays untouched.
install -d -m 0755 /usr/local/sbin
CTL_TMP="/usr/local/sbin/.vpsctl.rgnodes-$STAMP"
install -o root -g root -m 0755 "$STAGE_DIR/vpsctl-bin" "$CTL_TMP"
# A stale path might be a directory or symlink, not just an old regular file. Preserve such
# an object before replacing it; `mv -T` prevents silently moving the controller inside a dir.
if [[ -d /usr/local/sbin/vpsctl && ! -L /usr/local/sbin/vpsctl ]]; then
  LEGACY_CONTROLLER_PATH="/usr/local/sbin/vpsctl.legacy-dir-$STAMP"
  [[ ! -e "$LEGACY_CONTROLLER_PATH" && ! -L "$LEGACY_CONTROLLER_PATH" ]] || die "Refusing to overwrite existing legacy path: $LEGACY_CONTROLLER_PATH"
  mv -T -- /usr/local/sbin/vpsctl "$LEGACY_CONTROLLER_PATH" || die 'Could not preserve an unexpected directory at /usr/local/sbin/vpsctl.'
  warn "Preserved unexpected controller directory at $LEGACY_CONTROLLER_PATH."
fi
mv -fT -- "$CTL_TMP" /usr/local/sbin/vpsctl
python3 - "$APP_DIR/bot.py" /usr/local/sbin/vpsctl <<'PYPOSTCTL'
import hashlib, os, re, sys
from pathlib import Path
bot_path, ctl_path = map(Path, sys.argv[1:])
s = bot_path.read_text(encoding='utf-8')
h = re.search(r"_EMBEDDED_VPSCTL_SHA256\s*=\s*['"]([0-9a-f]{64})['"]", s)
data = ctl_path.read_bytes()
text = data.decode('utf-8', errors='replace')
if not h or hashlib.sha256(data).hexdigest() != h.group(1): raise SystemExit('Installed KVM controller hash does not match bot.py.')
if not all(x in text for x in ('KVM/QEMU/libvirt only', 'def compat(', 'virsh')): raise SystemExit('Installed KVM controller markers do not match.')
if not os.access(ctl_path, os.X_OK): raise SystemExit('Installed KVM controller is not executable.')
compile(data.decode('utf-8'), str(ctl_path), 'exec')
print('Installed controller verified:', ctl_path, hashlib.sha256(data).hexdigest())
PYPOSTCTL

install -d -m 0755 "$STATE_ROOT" "$STATE_ROOT/images" "$STATE_ROOT/disks" "$STATE_ROOT/seeds" "$STATE_ROOT/meta" "$STATE_ROOT/secrets" "$APP_DIR/db_backups" "$APP_DIR/vps_backups"
chmod 0700 "$STATE_ROOT/secrets"
QEMU_USER=''
for candidate in libvirt-qemu qemu; do if id "$candidate" >/dev/null 2>&1; then QEMU_USER="$candidate"; break; fi; done
if [[ -n "$QEMU_USER" ]] && command -v setfacl >/dev/null 2>&1; then
  setfacl -m "u:$QEMU_USER:rx" "$STATE_ROOT" 2>/dev/null || true
  for d in images disks seeds; do setfacl -m "u:$QEMU_USER:rwx" "$STATE_ROOT/$d" 2>/dev/null || true; find "$STATE_ROOT/$d" -type d -exec setfacl -m "d:u:$QEMU_USER:rwX" {} + 2>/dev/null || true; done
fi

mkdir -p /run/sshd
if command -v sshd >/dev/null 2>&1; then sshd -t || die 'Host sshd configuration test failed; provider SSH configuration was not overwritten.'; fi
if [[ "$(printf '%s' "$(env_get LOCAL_KVM_ENABLED)" | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]]; then
  for unit in libvirtd.service virtqemud.service virtlogd.service virtlockd.service ssh.service; do systemctl enable "$unit" >/dev/null 2>&1 || true; systemctl start "$unit" >/dev/null 2>&1 || true; done
else
  log 'Local KVM services were not modified; optional local virtualization remains disabled unless already configured by the host operator.'
fi

UNIT_TMP="$(mktemp /etc/systemd/system/.${SERVICE_NAME}.XXXXXX)"
cat > "$UNIT_TMP" <<EOFUNIT
[Unit]
Description=RGNODES™ VPS Bot - Local and Remote KVM/QEMU Controller
Wants=network-online.target
After=network-online.target
StartLimitIntervalSec=300
StartLimitBurst=5

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=$APP_DIR
Environment=HOME=/root
Environment=PYTHONUNBUFFERED=1
Environment=RGNODES_VPS_ROOT=$STATE_ROOT
EnvironmentFile=-$ENV_FILE
ExecStartPre=$APP_DIR/.venv/bin/python -m py_compile $APP_DIR/bot.py
ExecStart=$APP_DIR/.venv/bin/python -u $APP_DIR/bot.py
Restart=always
RestartSec=8
KillMode=control-group
TimeoutStartSec=180
TimeoutStopSec=60
LimitNOFILE=65535
CPUQuota=${BOT_CPU_QUOTA_PERCENT}%
MemoryHigh=$((BOT_MEMORY_MAX_MB * 80 / 100))M
MemoryMax=${BOT_MEMORY_MAX_MB}M
TasksMax=${BOT_TASKS_MAX}
Nice=5
CPUWeight=100
IOWeight=100
UMask=0077

[Install]
WantedBy=multi-user.target
EOFUNIT
chown root:root "$UNIT_TMP"; chmod 0644 "$UNIT_TMP"; mv -fT -- "$UNIT_TMP" "$SYSTEMD_UNIT_PATH"
if command -v systemd-analyze >/dev/null 2>&1; then
  systemd-analyze verify "$SYSTEMD_UNIT_PATH" || die 'systemd-analyze rejected the generated service unit; rollback will be attempted.'
else
  warn 'systemd-analyze is unavailable; unit syntax validation was skipped.'
fi
systemctl daemon-reload

step 'Phase 5/6 • Validating systemd policy and running the full static/regression suite...'
bash "$APP_DIR/check.sh" --static
if token_is_ready && [[ "$ADMIN_ID_CHECK" =~ ^[0-9]{15,22}$ ]]; then TOKEN_READY=yes; else TOKEN_READY=no; fi
if [[ "$TOKEN_READY" != yes ]]; then
  if (( WAS_ENABLED || WAS_ACTIVE )); then die "Existing $SERVICE_NAME had been enabled/active but DISCORD_TOKEN or MAIN_ADMIN_ID is not valid; refusing to disable or leave an update half-applied."; fi
  warn "DISCORD_TOKEN or MAIN_ADMIN_ID is missing/invalid. Code is installed but service remains disabled; correct .env and rerun setup.sh."
else
  systemctl enable "$SERVICE_NAME" >/dev/null
  systemctl is-enabled --quiet "$SERVICE_NAME" || die "$SERVICE_NAME was not enabled for 24/7 startup; inspect systemd policy and permissions."
  if (( WAS_ACTIVE )); then systemctl restart "$SERVICE_NAME"; else systemctl start "$SERVICE_NAME"; fi
  service_ready=0
  for ((attempt=1; attempt<=30; attempt++)); do
    if systemctl is-active --quiet "$SERVICE_NAME"; then service_ready=1; break; fi
    sleep 1
  done
  if (( service_ready == 0 )); then
    systemctl status --no-pager -l "$SERVICE_NAME" || true
    die "Service $SERVICE_NAME failed to become active within 30 seconds; rollback will be attempted. Inspect journalctl -u $SERVICE_NAME for the detailed diagnostic."
  fi
  log "Service $SERVICE_NAME is active and passed the bounded startup check."
  step 'Phase 6/6 • 24/7 service enabled; startup health check passed.'
fi

local_node_id=''
  for ((node_attempt=1; node_attempt<=10; node_attempt++)); do
    local_node_id="$(python3 - "$DATA_DIR/vps.db" <<'PYLOCALNODE' 2>/dev/null || true
import sqlite3,sys
try:
 c=sqlite3.connect('file:'+sys.argv[1]+'?mode=ro',uri=True,timeout=2)
 try:
  row=c.execute('SELECT id FROM nodes WHERE is_local=1 ORDER BY id LIMIT 1').fetchone()
  print(row[0] if row else '')
 finally: c.close()
except Exception: pass
PYLOCALNODE
)"
    [[ -n "$local_node_id" ]] && break
    sleep 1
  done
  if [[ -n "$local_node_id" ]]; then
    log "Local Node was automatically registered (ID $local_node_id); remote nodes remain available via -node create."
  else
    warn 'The bot service is active, but automatic Local Node registration has not been confirmed. Check journalctl and the configured database path before deploying.'
  fi

if [[ "$(printf '%s' "$(env_get LOCAL_KVM_ENABLED)" | tr '[:upper:]' '[:lower:]')" =~ ^(1|true|yes|on)$ ]]; then
  if [[ ! -e /dev/kvm ]]; then warn '/dev/kvm is missing: host KVM installation was requested but provider/nested virtualization is unavailable.'; fi
  if ! virsh -c qemu:///system list --all >/dev/null 2>&1; then warn 'libvirt qemu:///system is not ready; run sudo bash check.sh for diagnostics.'; fi
else
  log 'Local host KVM is optional and not installed by this setup selection; combined-mode routing can use any ready local KVM or registered remote node.'
fi
ROLLBACK_ARMED=0
printf '\n%b════════════════════ INSTALLATION COMPLETE ════════════════════%b\n' "$GRN" "$NC"
log 'Power By RGNODES™ — setup completed. Existing .env, database, VM disks, metadata and backups were preserved.'
log "24/7 service: $SERVICE_NAME (enabled at boot; systemd restarts it after failures)"
log "Service: systemctl status $SERVICE_NAME"
log "Logs: journalctl -u $SERVICE_NAME -f"
log "Restart: systemctl restart $SERVICE_NAME"
log "Config: $ENV_FILE (permissions 0600)"
log "Diagnostics: sudo bash $APP_DIR/check.sh"
if [[ ! -e /dev/kvm ]]; then warn 'The host bot may run, but actual VPS deployment remains unavailable until /dev/kvm and provider networking are enabled.'; fi
